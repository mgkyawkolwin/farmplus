export interface CustomerItem {
  id: string;
  name: string;
  profilePictureUrl?: string;
  nationalIdNumber?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  country?: string;
  postalCode?: string;
  isActive: boolean;
  totalOrders?: number;
  totalSales?: number;
  totalPaid?: number;
  totalOutstanding?: number;
  recentSales?: Array<{
    id: string;
    saleDate: string;
    netTotal: number;
    balance: number;
    status: string;
  }>;
  recentPayments?: Array<{
    id: string;
    saleId: string;
    amount: number;
    balanceAfter: number;
    paidAt: string;
  }>;
  rowVersion?: string;
  createdAtUtc?: string;
  createdById?: string;
  updatedAtUtc?: string;
  updatedById?: string;
}

export interface CustomerPayment {
  id: string;
  saleId: string;
  amount: number;
  balanceAfter: number;
  paidAt: string;
}

export interface CustomerPaymentListPayload {
  items?: CustomerPayment[];
  page?: number;
  pageSize?: number;
  totalCount?: number;
  totalPages?: number;
}

export interface CustomerListPayload {
  items?: CustomerItem[];
  page?: number;
  pageSize?: number;
  totalCount?: number;
  totalPages?: number;
}

export interface CreateCustomerRequest {
  name: string;
  profilePictureUrl?: string;
  nationalIdNumber?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  country?: string;
  postalCode?: string;
  isActive?: boolean;
}

export interface UpdateCustomerRequest {
  id: string;
  name: string;
  profilePictureUrl?: string;
  nationalIdNumber?: string;
  phone?: string;
  email?: string;
  address?: string;
  city?: string;
  country?: string;
  postalCode?: string;
  isActive?: boolean;
  rowVersion?: string;
}
