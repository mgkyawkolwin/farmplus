export interface ProductMediaItem {
  id?: string;
  objectName: string;
  mediaType: string;
  size: number;
  url?: string;
}

export interface ProductItem {
  id: string;
  name: string;
  description?: string;
  brand?: string;
  category?: string;
  unit?: string;
  salePrice?: number;
  currentStock?: number;
  minimumStock?: number;
  totalOrders?: number;
  totalQuantitySold?: number;
  totalRevenue?: number;
  isActive?: boolean;
  coverImageUrl?: string;
  medias?: ProductMediaItem[];
  rowVersion?: string;
  createdAtUtc?: string;
  createdById?: string;
  updatedAtUtc?: string;
  updatedById?: string;
}

export interface ProductListPayload {
  items?: ProductItem[];
  page?: number;
  pageSize?: number;
  totalCount?: number;
  totalPages?: number;
}

export interface InventoryMovement {
  id: string;
  productId: string;
  productName: string;
  shopId: string;
  shopName: string;
  quantity: number;
  type: string;
  remark?: string;
  createdAtUtc: string;
}

export interface InventoryMovementListPayload {
  items?: InventoryMovement[];
  page?: number;
  pageSize?: number;
  totalCount?: number;
  totalPages?: number;
}

export interface CreateProductRequest {
  name: string;
  description?: string;
  brand?: string;
  category?: string;
  unit?: string;
  salePrice?: number;
  currentStock?: number;
  minimumStock?: number;
  isActive?: boolean;
  coverImageUrl?: string;
  medias?: ProductMediaItem[];
}

export interface UpdateProductRequest {
  id: string;
  name?: string;
  description?: string;
  brand?: string;
  category?: string;
  unit?: string;
  salePrice?: number;
  currentStock?: number;
  minimumStock?: number;
  isActive?: boolean;
  coverImageUrl?: string;
  medias?: ProductMediaItem[];
  rowVersion?: string;
}
