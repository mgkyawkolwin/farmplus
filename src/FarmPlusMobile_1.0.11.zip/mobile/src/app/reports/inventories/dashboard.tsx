"use client";

import * as React from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { useFocusEffect, useRouter, type Href } from "expo-router";
import {
  AlertTriangle,
  Boxes,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Layers,
  Package,
  Repeat,
  TrendingDown,
  TrendingUp,
  Wallet,
} from "lucide-react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useColorScheme } from "nativewind";

import {
  BarChart,
  DonutChart,
  LineChart,
  RankedBars,
  compactNumber,
} from "@/components/charts";
import LoadingOverlay from "@/components/loadingOverlay";
import UnauthorizedView from "@/components/unauthorized-view";
import { Button } from "@/components/ui/button";
import { Icon } from "@/components/ui/icon";
import { Text } from "@/components/ui/text";
import SnackBar from "@/components/ui/snack-bar";
import { container, DI_TOKENS } from "@/di";
import { InventoryMovement, ProductItem } from "@/models/product";
import { getInventoryProducts } from "@/services/inventoryService";
import { IProductService } from "@/services/productService";
import { useSelectedShopChanged } from "@/lib/selectedShop";
import { THEME } from "@/lib/theme";
import { usePagePermission } from "@/lib/usePagePermission";
import { useTranslation } from 'react-i18next';

const productService = container.resolve<IProductService>(DI_TOKENS.IProductService);

type ThemeColors = typeof THEME.light;

function getColors(theme: ThemeColors) {
  return {
    ink: theme.foreground,
    muted: theme.mutedForeground,
    border: theme.border,
    green: theme.chart2,
    blue: theme.chart1,
    amber: theme.chart4,
    red: theme.destructive,
    purple: theme.chart5,
    slate: theme.chart3,
  };
}

type Tone = "green" | "blue" | "amber" | "red";

function getToneColors(tone: Tone, theme: ThemeColors) {
  const colors = getColors(theme);
  return { fg: colors[tone], bg: theme.secondary, border: theme.border };
}

const PAGE_SIZE = 500;
const DAY = 86_400_000;

function count(value: number) {
  return value.toLocaleString("en-US");
}

function money(value: number) {
  return `${value.toLocaleString("en-US", { maximumFractionDigits: 0 })} MMK`;
}

function monthKey(date: Date) {
  return date.getFullYear() * 12 + date.getMonth();
}

function timestamp(value?: string) {
  if (!value) return 0;
  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
}

function movementIsTransfer(type: string) {
  return type.toLowerCase().includes("transfer");
}

function Section({
  title,
  subtitle,
  onViewAll,
  theme,
  children,
}: {
  title: string;
  subtitle?: string;
  onViewAll?: () => void;
  theme: ThemeColors;
  children: React.ReactNode;
}) {
  const { t } = useTranslation();
  const colors = getColors(theme);
  return (
    <View>
      <View style={styles.sectionHeading}>
        <View style={styles.sectionTitleBlock}>
            <Text style={[styles.sectionTitle, { color: colors.ink }]}>{title}</Text>
          {subtitle ? <Text style={[styles.sectionSubtitle, { color: colors.muted }]}>{subtitle}</Text> : null}
        </View>
        {onViewAll ? (
          <Pressable style={styles.seeAll} onPress={onViewAll}>
            <Text style={[styles.seeAllText, { color: colors.green }]}>{t('reports.common.viewAll')}</Text>
            <ChevronRight size={14} color={colors.green} />
          </Pressable>
        ) : null}
      </View>
      <View style={[styles.panel, { backgroundColor: theme.card, borderColor: theme.border }]}>{children}</View>
    </View>
  );
}

function Kpi({
  label,
  value,
  caption,
  icon: IconComponent,
  tone,
  theme,
}: {
  label: string;
  value: string;
  caption: string;
  icon: typeof Wallet;
  tone: Tone;
  theme: ThemeColors;
}) {
  const palette = getToneColors(tone, theme);
  return (
    <View
      style={[
        styles.kpi,
        {
          backgroundColor: palette.bg,
          borderColor: palette.border,
          borderTopColor: palette.fg,
        },
      ]}
    >
      <View style={styles.kpiHeader}>
        <View style={[styles.kpiIcon, { backgroundColor: theme.secondary }]}>
          <IconComponent size={16} color={palette.fg} />
        </View>
          <Text style={[styles.kpiLabel, { color: theme.mutedForeground }]} numberOfLines={1}>{label}</Text>
      </View>
      <Text style={[styles.kpiValue, { color: theme.foreground }]} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>
        {value}
      </Text>
      <Text style={[styles.kpiCaption, { color: theme.mutedForeground }]} numberOfLines={1}>{caption}</Text>
    </View>
  );
}

type CategoryStats = { name: string; skus: number; units: number; value: number };
type ProductMovementStats = { id: string; name: string; units: number; events: number };
type MovementTypeStats = { name: string; quantity: number; events: number };

export default function InventoryReportDashboardScreen() {
  const router = useRouter();
  const { t, i18n } = useTranslation();
  const { colorScheme } = useColorScheme() ?? { colorScheme: "light" };
  const theme = colorScheme === "dark" ? THEME.dark : THEME.light;
  const colors = getColors(theme);
  const permissionState = usePagePermission('/reports/inventories/dashboard');
  const [products, setProducts] = React.useState<ProductItem[]>([]);
  const [movements, setMovements] = React.useState<InventoryMovement[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const load = React.useCallback(async () => {
    const [productResult, movementResult] = await Promise.allSettled([
      getInventoryProducts(),
      (async () => {
        const all: InventoryMovement[] = [];
        let page = 1;
        while (true) {
          const next = await productService.getInventoryMovements(page, PAGE_SIZE);
          all.push(...next);
          if (next.length < PAGE_SIZE) break;
          page += 1;
        }
        return all;
      })(),
    ]);

    if (productResult.status === "rejected" && movementResult.status === "rejected") {
      SnackBar.Error(t('reports.common.loadFailed'));
    }
    setProducts(productResult.status === "fulfilled" ? productResult.value : []);
    setMovements(movementResult.status === "fulfilled" ? movementResult.value : []);
    setLoading(false);
    setRefreshing(false);
  }, [t]);

  useFocusEffect(
    React.useCallback(() => {
      if (permissionState !== 'authorized') return undefined;
      setLoading(true);
      void load();
      return undefined;
    }, [load, permissionState]),
  );

  useSelectedShopChanged(() => {
    if (permissionState === 'authorized') void load();
  });

  const report = React.useMemo(() => {
    const now = new Date();
    const nowMs = now.getTime();
    const stockUnits = products.reduce((sum, product) => sum + Math.max(product.currentStock ?? 0, 0), 0);
    const stockValue = products.reduce(
      (sum, product) => sum + Math.max(product.currentStock ?? 0, 0) * Math.max(product.salePrice ?? 0, 0),
      0,
    );
    const activeProducts = products.filter((product) => product.isActive !== false).length;
    const outOfStockProducts = products.filter((product) => (product.currentStock ?? 0) <= 0);
    const lowStockProducts = products.filter((product) => {
      const stock = product.currentStock ?? 0;
      const minimum = product.minimumStock ?? 0;
      return stock > 0 && minimum > 0 && stock <= minimum;
    }).sort((left, right) => (left.currentStock ?? 0) - (right.currentStock ?? 0));
    const healthyStock = Math.max(products.length - outOfStockProducts.length - lowStockProducts.length, 0);

    const monthly = Array.from({ length: 12 }, (_, index) => {
      const date = new Date(now.getFullYear(), now.getMonth() - (11 - index), 1);
      return {
        key: monthKey(date),
        label: date.toLocaleDateString(i18n.language, { month: "short" }),
        stockIn: 0,
        stockOut: 0,
        transferIn: 0,
        transferOut: 0,
        events: 0,
      };
    });
    const monthBuckets = new Map(monthly.map((item) => [item.key, item]));
    const categoryMap = new Map<string, CategoryStats>();
    const productMap = new Map<string, ProductMovementStats>();
    const typeMap = new Map<string, MovementTypeStats>();
    let stockIn = 0;
    let stockOut = 0;
    let transferUnits = 0;
    let damageUnits = 0;
    let movementsLast30 = 0;

    products.forEach((product) => {
      const name = product.category?.trim() || "Uncategorized";
      const category = categoryMap.get(name) ?? { name, skus: 0, units: 0, value: 0 };
      const units = Math.max(product.currentStock ?? 0, 0);
      category.skus += 1;
      category.units += units;
      category.value += units * Math.max(product.salePrice ?? 0, 0);
      categoryMap.set(name, category);
    });

    movements.forEach((movement) => {
      const quantity = movement.quantity;
      const absoluteQuantity = Math.abs(quantity);
      const transfer = movementIsTransfer(movement.type);
      const isIn = quantity > 0;
      const time = timestamp(movement.createdAtUtc);
      const month = monthBuckets.get(monthKey(new Date(time)));
      if (time > 0 && nowMs - time <= 30 * DAY) movementsLast30 += 1;

      if (transfer) {
        transferUnits += absoluteQuantity;
        if (month) {
          if (isIn) month.transferIn += absoluteQuantity;
          else month.transferOut += absoluteQuantity;
        }
      } else if (isIn) {
        stockIn += absoluteQuantity;
        if (month) month.stockIn += absoluteQuantity;
      } else {
        stockOut += absoluteQuantity;
        if (month) month.stockOut += absoluteQuantity;
        if (movement.type.toLowerCase().includes("damage")) damageUnits += absoluteQuantity;
      }
      if (month) month.events += 1;

      const type = typeMap.get(movement.type) ?? { name: movement.type, quantity: 0, events: 0 };
      type.quantity += absoluteQuantity;
      type.events += 1;
      typeMap.set(movement.type, type);

      const product = productMap.get(movement.productId) ?? {
        id: movement.productId,
        name: movement.productName,
        units: 0,
        events: 0,
      };
      product.units += absoluteQuantity;
      product.events += 1;
      productMap.set(movement.productId, product);
    });

    const typeStats = [...typeMap.values()].sort((left, right) => right.quantity - left.quantity);
    const categories = [...categoryMap.values()].sort((left, right) => right.value - left.value);
    const topProducts = [...productMap.values()].sort((left, right) => right.units - left.units).slice(0, 8);
    const recentMovements = [...movements]
      .sort((left, right) => timestamp(right.createdAtUtc) - timestamp(left.createdAtUtc))
      .slice(0, 10);
    const newProductsLast30 = products.filter((product) =>
      product.createdAtUtc && nowMs - timestamp(product.createdAtUtc) <= 30 * DAY,
    ).length;

    return {
      stockUnits,
      stockValue,
      activeProducts,
      outOfStockProducts,
      lowStockProducts,
      healthyStock,
      monthly,
      categories,
      typeStats,
      topProducts,
      recentMovements,
      stockIn,
      stockOut,
      transferUnits,
      damageUnits,
      movementsLast30,
      newProductsLast30,
    };
  }, [movements, products, i18n.language]);

  const otherCategoryValue = Math.max(report.stockValue - report.categories.slice(0, 5).reduce((sum, item) => sum + item.value, 0), 0);
  const categorySlices = [
    ...report.categories.slice(0, 5).map((category, index) => ({
      label: category.name === 'Uncategorized' ? t('reports.inventory.labels.uncategorized') : category.name,
      value: category.value,
      color: [colors.green, colors.blue, colors.amber, colors.purple, colors.red][index],
    })),
    ...(otherCategoryValue > 0 ? [{ label: t('reports.inventory.chart.other'), value: otherCategoryValue, color: colors.slate }] : []),
  ];
  const movementLabel = (type: string) => {
    const normalized = type.toLowerCase();
    if (normalized.includes('transfer')) return t('reports.inventory.movement.transfer');
    if (normalized.includes('damage')) return t('reports.inventory.movement.damage');
    if (normalized.includes('stock-in') || normalized.includes('stock in')) return t('reports.inventory.movement.stockIn');
    if (normalized.includes('stock-out') || normalized.includes('stock out')) return t('reports.inventory.movement.stockOut');
    return type;
  };
  const stockListRoute = "/inventory/list" as Href;
  const openProduct = (id: string) => router.push({ pathname: "/inventory/view", params: { id } } as Href);

  return (
    <SafeAreaView className="bg-background" style={styles.page}>
      <LoadingOverlay isLoading={permissionState === 'authorized' && loading} />
      <View className="bg-background border-b border-border" style={styles.headerBar}>
        <Button variant="ghost" onPress={() => router.back()} style={styles.headerButton}>
          <Icon className="text-foreground" as={ChevronLeft} size={22} />
        </Button>
        <Text className="text-foreground" style={styles.headerTitle}>{t('reports.inventory.title')}</Text>
        <View style={styles.headerButton} />
      </View>

      {permissionState === 'checking' ? (
        <View style={styles.centeredState}><ActivityIndicator size="large" color={colors.green} /><Text className="text-muted-foreground" style={styles.stateText}>{t('reports.common.checkingPermission')}</Text></View>
      ) : permissionState === 'denied' ? (
        <UnauthorizedView title={t('reports.common.unauthorizedTitle')} message={t('reports.common.unauthorizedDescription')} />
      ) : <ScrollView
        contentContainerStyle={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => {
          setRefreshing(true);
          void load();
        }} />}
      >
        <View>
          <Text style={[styles.eyebrow, { color: colors.green }]}>{t('reports.inventory.eyebrow')}</Text>
          <Text style={[styles.title, { color: colors.ink }]}>{t('reports.inventory.overview')}</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>
            {t('reports.inventory.subtitle', { count: count(products.length) })}
          </Text>
        </View>

        <View style={styles.kpiGrid}>
          <Kpi label={t('reports.inventory.kpi.stockOnHand')} value={count(report.stockUnits)} caption={t('reports.inventory.caption.unitsAllProducts')} icon={Boxes} tone="green" theme={theme} />
          <Kpi label={t('reports.inventory.kpi.stockValue')} value={money(report.stockValue)} caption={t('reports.inventory.caption.atSalePrice')} icon={Wallet} tone="blue" theme={theme} />
          <Kpi label={t('reports.inventory.kpi.activeProducts')} value={count(report.activeProducts)} caption={t('reports.inventory.caption.inactive', { count: count(products.length - report.activeProducts) })} icon={Package} tone="green" theme={theme} />
          <Kpi label={t('reports.inventory.kpi.lowStock')} value={count(report.lowStockProducts.length)} caption={t('reports.inventory.caption.atOrBelowMinimum')} icon={AlertTriangle} tone={report.lowStockProducts.length > 0 ? "amber" : "green"} theme={theme} />
          <Kpi label={t('reports.inventory.kpi.outOfStock')} value={count(report.outOfStockProducts.length)} caption={t('reports.inventory.caption.skusAtZero')} icon={AlertTriangle} tone={report.outOfStockProducts.length > 0 ? "red" : "green"} theme={theme} />
          <Kpi label={t('reports.inventory.kpi.stockIn')} value={count(report.stockIn)} caption={t('reports.inventory.caption.unitsMovementHistory')} icon={TrendingUp} tone="green" theme={theme} />
          <Kpi label={t('reports.inventory.kpi.stockOut')} value={count(report.stockOut)} caption={t('reports.inventory.caption.unitsExcludingTransfers')} icon={TrendingDown} tone="amber" theme={theme} />
          <Kpi label={t('reports.inventory.kpi.transfer')} value={count(report.transferUnits)} caption={t('reports.inventory.caption.unitsMovedBetweenShops')} icon={Repeat} tone="blue" theme={theme} />
          <Kpi label={t('reports.inventory.kpi.damage')} value={count(report.damageUnits)} caption={t('reports.inventory.caption.unitsWrittenOff')} icon={AlertTriangle} tone={report.damageUnits > 0 ? "red" : "green"} theme={theme} />
          <Kpi label={t('reports.inventory.kpi.events30')} value={count(report.movementsLast30)} caption={t('reports.inventory.caption.newSkus', { count: count(report.newProductsLast30) })} icon={CalendarDays} tone="blue" theme={theme} />
        </View>

        <Section title={t('reports.inventory.section.movementTrend')} subtitle={t('reports.inventory.subtitleSection.movementTrend')} theme={theme}>
          <LineChart
            labels={report.monthly.map((month) => month.label)}
            series={[
              { name: t('reports.inventory.series.stockIn'), color: colors.green, values: report.monthly.map((month) => month.stockIn) },
              { name: t('reports.inventory.series.stockOut'), color: colors.amber, values: report.monthly.map((month) => month.stockOut) },
            ]}
          />
        </Section>

        <Section title={t('reports.inventory.section.movementEvents')} subtitle={t('reports.inventory.subtitleSection.eventCount')} theme={theme}>
          <BarChart
            data={report.monthly.map((month) => ({ label: month.label, values: [month.events] }))}
            series={[{ name: t('reports.inventory.series.movementEvents'), color: colors.blue }]}
            height={160}
          />
        </Section>

        <Section title={t('reports.inventory.section.stockHealth')} subtitle={t('reports.inventory.subtitleSection.currentSku')} theme={theme}>
          <DonutChart
            centerLabel={t('reports.inventory.chart.products')}
            centerValue={count(products.length)}
            slices={[
              { label: t('reports.inventory.chart.healthy'), value: report.healthyStock, color: colors.green },
              { label: t('reports.inventory.chart.lowStock'), value: report.lowStockProducts.length, color: colors.amber },
              { label: t('reports.inventory.chart.outOfStock'), value: report.outOfStockProducts.length, color: colors.red },
            ]}
            formatValue={count}
          />
        </Section>

        <Section title={t('reports.inventory.section.categoryValue')} subtitle={t('reports.inventory.subtitleSection.currentValue')} theme={theme}>
          <DonutChart
            centerLabel={t('reports.inventory.chart.stockValue')}
            centerValue={compactNumber(report.stockValue)}
            slices={categorySlices}
            formatValue={money}
          />
        </Section>

        <Section title={t('reports.inventory.section.movementType')} subtitle={t('reports.inventory.subtitleSection.unitsByType')} theme={theme}>
          <RankedBars
            items={report.typeStats.slice(0, 8).map((type) => ({
              label: movementLabel(type.name),
              value: type.quantity,
              caption: `${count(type.events)} events`,
            }))}
            color={colors.purple}
            formatValue={count}
            emptyText={t('reports.inventory.empty.noMovements')}
          />
        </Section>

        <Section title={t('reports.inventory.section.mostMovement')} subtitle={t('reports.inventory.subtitleSection.absoluteUnits')} theme={theme}>
          <RankedBars
            items={report.topProducts.map((product) => ({
              label: product.name,
              value: product.units,
              caption: `${count(product.events)} events`,
            }))}
            color={colors.blue}
            formatValue={count}
            emptyText={t('reports.inventory.empty.noMovements')}
          />
        </Section>

        <Section title={t('reports.inventory.section.reorderAttention')} subtitle={t('reports.inventory.subtitleSection.reorder')} onViewAll={() => router.push(stockListRoute)} theme={theme}>
          <View style={[styles.table, { borderColor: theme.border }]}>
            <View style={[styles.tableHeader, { backgroundColor: theme.secondary }]}>
              <Text style={[styles.th, styles.tdWide, { color: colors.muted }]}>{t('reports.inventory.field.product')}</Text>
              <Text style={[styles.th, styles.tdSmall, { color: colors.muted }]}>{t('reports.inventory.field.stock')}</Text>
              <Text style={[styles.th, styles.tdNum, { color: colors.muted }]}>{t('reports.inventory.field.minimum')}</Text>
            </View>
            {report.outOfStockProducts.concat(report.lowStockProducts).slice(0, 8).map((product) => (
              <Pressable key={product.id} style={[styles.tableRow, { borderTopColor: theme.border }]} onPress={() => openProduct(product.id)}>
                <View style={styles.tdWide}>
                  <Text style={[styles.td, { color: colors.ink }]} numberOfLines={1}>{product.name}</Text>
                  <Text style={[styles.tdSub, { color: colors.muted }]} numberOfLines={1}>{product.category || t('reports.inventory.labels.uncategorized')}</Text>
                </View>
                <Text style={[styles.td, styles.tdSmall, { color: colors.amber, fontWeight: "700" }]}>{count(product.currentStock ?? 0)}</Text>
                <Text style={[styles.td, styles.tdNum, { color: colors.ink }]}>{count(product.minimumStock ?? 0)}</Text>
              </Pressable>
            ))}
            {report.outOfStockProducts.length + report.lowStockProducts.length === 0 ? (
              <Text style={[styles.empty, { color: colors.muted }]}>{t('reports.inventory.empty.aboveMinimum')}</Text>
            ) : null}
          </View>
        </Section>

        <Section title={t('reports.inventory.section.recentMovements')} subtitle={t('reports.inventory.subtitleSection.latestEvents')} theme={theme}>
          <View style={[styles.table, { borderColor: theme.border }]}>
            <View style={[styles.tableHeader, { backgroundColor: theme.secondary }]}>
              <Text style={[styles.th, styles.tdWide, { color: colors.muted }]}>{t('reports.inventory.field.product')}</Text>
              <Text style={[styles.th, styles.tdSmall, { color: colors.muted }]}>{t('reports.inventory.field.type')}</Text>
              <Text style={[styles.th, styles.tdNum, { color: colors.muted }]}>{t('reports.inventory.field.quantity')}</Text>
              <Text style={[styles.th, styles.tdNum, { color: colors.muted }]}>{t('reports.inventory.field.date')}</Text>
            </View>
            {report.recentMovements.map((movement) => (
              <Pressable key={movement.id} style={[styles.tableRow, { borderTopColor: theme.border }]} onPress={() => openProduct(movement.productId)}>
                <View style={styles.tdWide}>
                  <Text style={[styles.td, { color: colors.ink }]} numberOfLines={1}>{movement.productName}</Text>
                  <Text style={[styles.tdSub, { color: colors.muted }]} numberOfLines={1}>{movement.shopName}</Text>
                </View>
                <Text style={[styles.td, styles.tdSmall, { color: colors.ink }]} numberOfLines={1}>{movementLabel(movement.type)}</Text>
                <Text style={[styles.td, styles.tdNum, { color: movement.quantity < 0 ? colors.red : colors.green, fontWeight: "700" }]}>
                  {movement.quantity > 0 ? "+" : ""}{count(movement.quantity)}
                </Text>
                <Text style={[styles.td, styles.tdNum, { color: colors.ink }]} numberOfLines={1}>
                  {new Date(timestamp(movement.createdAtUtc)).toLocaleDateString()}
                </Text>
              </Pressable>
            ))}
            {report.recentMovements.length === 0 ? <Text style={[styles.empty, { color: colors.muted }]}>{t('reports.inventory.empty.noMovements')}</Text> : null}
          </View>
        </Section>
      </ScrollView>}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  headerBar: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 8, paddingVertical: 6 },
  headerButton: { minWidth: 40 },
  headerTitle: { flex: 1, textAlign: "center", fontSize: 18, fontWeight: "600" },
  content: { padding: 16, gap: 16, paddingBottom: 32 },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 0.6, textTransform: "uppercase" },
  title: { fontSize: 22, fontWeight: "800" },
  subtitle: { fontSize: 12, marginTop: 2 },
  kpiGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  kpi: { width: "48%", padding: 12, gap: 6, borderWidth: 1, borderTopWidth: 3, borderRadius: 6 },
  kpiHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  kpiIcon: { width: 26, height: 26, borderRadius: 6, alignItems: "center", justifyContent: "center" },
  kpiLabel: { flex: 1, fontSize: 10, fontWeight: "800", letterSpacing: 0.4, textTransform: "uppercase" },
  kpiValue: { fontSize: 18, fontWeight: "800" },
  kpiCaption: { fontSize: 11 },
  sectionHeading: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
  sectionTitleBlock: { flex: 1 },
  sectionTitle: { fontSize: 14, fontWeight: "800" },
  sectionSubtitle: { fontSize: 11, marginTop: 1 },
  seeAll: { flexDirection: "row", alignItems: "center", gap: 2 },
  seeAllText: { fontSize: 12, fontWeight: "700" },
  panel: { padding: 14, borderWidth: 1, borderRadius: 8 },
  table: { borderWidth: 1, borderRadius: 6, overflow: "hidden" },
  tableHeader: { flexDirection: "row", alignItems: "center", minHeight: 30, paddingHorizontal: 10, gap: 6 },
  th: { fontSize: 10, fontWeight: "800", letterSpacing: 0.4, textTransform: "uppercase" },
  tableRow: { flexDirection: "row", alignItems: "center", minHeight: 40, paddingHorizontal: 10, paddingVertical: 6, gap: 6, borderTopWidth: StyleSheet.hairlineWidth },
  td: { fontSize: 12 },
  tdSub: { fontSize: 10 },
  tdWide: { flex: 2, minWidth: 0 },
  tdSmall: { flex: 1, textAlign: "right" },
  tdNum: { flex: 1.1, textAlign: "right" },
  centeredState: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24 },
  stateText: { marginTop: 8, textAlign: "center" },
  empty: { padding: 14, textAlign: "center", fontSize: 12 },
});