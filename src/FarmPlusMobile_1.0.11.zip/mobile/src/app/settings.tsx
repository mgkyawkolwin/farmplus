import { useState } from 'react';
import appConfig from '../../app.json';
import {
  StyleSheet,
  ScrollView,
  View,
  TouchableOpacity,
  Switch,
  Modal,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next';
import { useRouter } from 'expo-router';
import { Icon } from '@/components/ui/icon';
import { Text } from '@/components/ui/text';
import { ChevronLeft, ChevronRight, Globe, Moon } from 'lucide-react-native';

// 1. Import useColorScheme from nativewind, NOT react-native
import { useColorScheme } from 'nativewind';
import { THEME } from '@/lib/theme';
import { storeColorScheme } from '@/lib/colorSchemeStorage';

interface LanguageOption {
  code: string;
  labelKey: string;
}

const LANGUAGES: LanguageOption[] = [
  { code: 'en', labelKey: 'title.english' },
  { code: 'my', labelKey: 'title.myanmar' },
  { code: 'th', labelKey: 'title.thai' },
  { code: 'zh', labelKey: 'title.chinese' },
  { code: 'lo', labelKey: 'title.laos' },
  { code: 'km', labelKey: 'title.cambodia' },
  { code: 'vi', labelKey: 'title.vietnam' },
  { code: 'ms', labelKey: 'title.malaysia' },
  { code: 'id', labelKey: 'title.indonesia' },
  { code: 'hi', labelKey: 'title.india' },
  { code: 'fil', labelKey: 'title.philippines' },
];

export default function SettingsScreen() {
  const { t, i18n } = useTranslation();
  const router = useRouter();

  // 2. Destructure colorScheme and setColorScheme from NativeWind
  const { colorScheme, setColorScheme } = useColorScheme();
  const theme = colorScheme === 'dark' ? THEME.dark : THEME.light;

  const [languageModalVisible, setLanguageModalVisible] = useState(false);

  const normalizedLanguage = i18n.language === 'mm' ? 'my' : i18n.language;
  const currentLanguage = LANGUAGES.find((l) => l.code === normalizedLanguage) ?? LANGUAGES[0];
  const appVersion = appConfig.expo?.version ?? '1.0.0';

  const handleLanguageSelect = (code: string) => {
    i18n.changeLanguage(code);
    setLanguageModalVisible(false);
  };

  // 3. Update the theme toggle handler
  const handleDarkModeToggle = (value: boolean) => {
    const scheme = value ? 'dark' : 'light';
    setColorScheme(scheme);
    storeColorScheme(scheme);
  };

  return (
    <SafeAreaView className="flex-1 bg-background" style={styles.container}>
      {/* Top Navigation Bar */}
      <View className="bg-background border-b-separator" style={styles.topBar}>
        <TouchableOpacity style={styles.topBarButton} onPress={() => router.back()} activeOpacity={0.7}>
          <Icon className='text-foreground' as={ChevronLeft} size={24} />
        </TouchableOpacity>
        <Text style={styles.topBarTitle}>
          {t('title.settings')}
        </Text>
        <View style={styles.topBarButton} />
      </View>

      {/* Content Area */}
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        <View className='bg-card border border-cardBorder' style={styles.card}>
          {/* Language Row */}
          <TouchableOpacity
            style={styles.cardRow}
            activeOpacity={0.7}
            onPress={() => setLanguageModalVisible(true)}
          >
            <View style={styles.cardRowLeft}>
              <Icon className='text-primary' as={Globe} size={20} />
              <Text className='text-accent' style={styles.cardRowLabel}>
                {t('title.language')}
              </Text>
            </View>
            <View style={styles.cardRowRight}>
              <Text className='text-value' style={styles.cardRowValue}>
                {t(currentLanguage.labelKey)}
              </Text>
              <Icon className='text-muted' as={ChevronRight} size={16} />
            </View>
          </TouchableOpacity>

          <View className='bg-separator' style={styles.separator} />

          {/* Dark Mode Row */}
          <View style={styles.cardRow}>
            <View style={styles.cardRowLeft}>
              <Icon className='text-primary' as={Moon} size={20} />
              <Text className='text-text' style={styles.cardRowLabel}>
                {t('title.darkMode')}
              </Text>
            </View>
            <Switch
              value={colorScheme === 'dark'}
              onValueChange={handleDarkModeToggle}
              trackColor={{ false: theme.muted, true: theme.primary }}
              thumbColor={theme.card}
            />
          </View>
        </View>
      </ScrollView>

      <Text className='text-muted-foreground' style={styles.versionText}>
        {t('title.version')} {appVersion}
      </Text>

      {/* Language Selection Modal */}
      <Modal
        visible={languageModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setLanguageModalVisible(false)}
      >
        <TouchableOpacity
          className='bg-popover'
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setLanguageModalVisible(false)}
        >
          <View className='bg-card' style={styles.modalContent}>
            <View style={[styles.modalHandle, { backgroundColor: theme.border }]} />
            <Text className='text-foreground' style={styles.modalTitle}>
              {t('title.selectLanguage')}
            </Text>
            <FlatList
              data={LANGUAGES}
              keyExtractor={(item) => item.code}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.languageItem}
                  onPress={() => handleLanguageSelect(item.code)}
                  activeOpacity={0.7}
                >
                  <Text className='text-foreground' style={styles.languageLabel}>
                    {t(item.labelKey)}
                  </Text>
                  {item.code === i18n.language && (
                    <Icon className='text-foreground' as={ChevronRight} size={16} />
                  )}
                </TouchableOpacity>
              )}
              ItemSeparatorComponent={() => (
                <View className='bg-separator' style={styles.separator} />
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
  },
  topBarButton: {
    padding: 4,
    width: 32,
  },
  topBarTitle: {
    fontSize: 20,
    fontWeight: '700',
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: 16,
    gap: 8,
    paddingBottom: 48,
  },
  versionText: {
    position: 'absolute',
    bottom: 16,
    alignSelf: 'center',
    fontSize: 12,
  },
  card: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden',
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  cardRowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  cardRowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  cardRowLabel: {
    fontSize: 15,
    fontWeight: '500',
  },
  cardRowValue: {
    fontSize: 14,
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    marginHorizontal: 16,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingBottom: 32,
    maxHeight: '50%',
  },
  modalHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 8,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 8,
  },
  languageItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  languageLabel: {
    fontSize: 15,
  },
});