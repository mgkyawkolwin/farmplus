'use client';

import * as React from 'react';
import {
  ActivityIndicator,
  Alert as RNAlert,
  Image,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  View,
  KeyboardAvoidingView,
  Platform,
  Switch,
} from 'react-native';
import { ThemedStatusBar as StatusBar } from "@/components/themed-status-bar";
import * as ImagePicker from 'expo-image-picker';
import {
  Plus,
  Pencil,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
  Image as ImageIcon,
} from 'lucide-react-native';

import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Text } from '@/components/ui/text';
import { DealerServiceClient } from '@/services/dealerService';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Icon } from '@/components/ui/icon';
import { DealerItem } from '@/models/dealer';
import { normalizeMediaFile } from '@/lib/mediaFile';
import SnackBar from '@/components/ui/snack-bar';
import UnauthorizedView from '@/components/unauthorized-view';
import { usePagePermission } from '@/lib/usePagePermission';
import { useColorScheme } from 'nativewind';
import { THEME } from '@/lib/theme';
import { useTranslation } from 'react-i18next';

export default function DealersScreen() {
  const router = useRouter();
  const { t } = useTranslation();
  const { colorScheme } = useColorScheme() ?? { colorScheme: 'light' };
  const theme = colorScheme === 'dark' ? THEME.dark : THEME.light;
  const permissionState = usePagePermission('/dealers/dealers');
  const service = React.useMemo(() => new DealerServiceClient(), []);

  const [dealers, setDealers] = React.useState<DealerItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [refreshing, setRefreshing] = React.useState(false);
  const [loadingMore, setLoadingMore] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [hasMore, setHasMore] = React.useState(true);
  const [modalVisible, setModalVisible] = React.useState(false);
  const [editingDealer, setEditingDealer] = React.useState<DealerItem | null>(
    null,
  );
  const [logoImage, setLogoImage] = React.useState<string | null>(null);
  const [logoFile, setLogoFile] = React.useState<{
    uri: string;
    name: string;
    type: string;
  } | null>(null);
  const [errorMessage, setErrorMessage] = React.useState<string | null>(null);

  const loadDealers = React.useCallback(
    async (requestedPage = 1, append = false, isRefresh = false) => {
      try {
        if (requestedPage === 1 && !append) {
          setLoading(true);
        }
        if (requestedPage > 1) {
          setLoadingMore(true);
        }
        if (isRefresh) {
          setRefreshing(true);
        }
        setErrorMessage(null);

        const data = await service.getDealers(requestedPage, 20);
        setDealers((prev) =>
          requestedPage === 1 || !append ? data : [...prev, ...data],
        );
        setPage(requestedPage);
        setHasMore(data.length >= 20);
      } catch (error: any) {
        setErrorMessage(error?.message || t('dealers.messages.unableLoad'));
      } finally {
        setLoading(false);
        setRefreshing(false);
        setLoadingMore(false);
      }
    },
    [service, t],
  );

  React.useEffect(() => {
    if (permissionState !== 'authorized') return undefined;
    void loadDealers(1, false, false);
  }, [loadDealers, permissionState]);

  const handleRefresh = React.useCallback(() => {
    void loadDealers(1, false, true);
  }, [loadDealers]);

  const handleLoadMore = React.useCallback(() => {
    if (loadingMore || !hasMore || loading || refreshing) {
      return;
    }
    void loadDealers(page + 1, true, false);
  }, [hasMore, loading, loadingMore, page, refreshing, loadDealers]);

  const handleScroll = React.useCallback(
    (event: any) => {
      const { layoutMeasurement, contentOffset, contentSize } =
        event.nativeEvent;
      if (
        layoutMeasurement.height + contentOffset.y >=
        contentSize.height - 24
      ) {
        handleLoadMore();
      }
    },
    [handleLoadMore],
  );

  const openCreateModal = () => {
    setEditingDealer({
      id: '',
      dealerName: '',
      isActive: false,
      email: undefined,
      phoneNumber: undefined,
      address: undefined,
      stateDivision: undefined,
      city: undefined,
      country: undefined,
      logoUrl: undefined,
      rowVersion: '',
      createdAtUtc: '',
      updatedAtUtc: '',
    });
    setLogoImage(null);
    setLogoFile(null);
    setErrorMessage(null);
    setModalVisible(true);
  };

  const openEditModal = (dealer: DealerItem) => {
    setEditingDealer(dealer);
    setLogoImage(dealer.logoUrl ?? null);
    setLogoFile(null);
    setErrorMessage(null);
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setEditingDealer(null);
    setLogoImage(null);
    setLogoFile(null);
    setErrorMessage(null);
  };

  const pickLogo = async () => {
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permissionResult.status !== ImagePicker.PermissionStatus.GRANTED) {
      SnackBar.Error(t('dealers.messages.photosPermission'));
      return;
    }

    const pickerResult = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 0.8,
    });

    if (pickerResult.canceled || !pickerResult.assets?.length) {
      return;
    }

    const asset = pickerResult.assets[0];
    if (!asset.uri) {
      return;
    }

    const uri = asset.uri;
    const normalizedFile = normalizeMediaFile({
      uri,
      fileName: asset.fileName,
      mimeType: asset.mimeType,
      assetType: asset.type,
      fallbackName: 'dealer-logo',
    });

    setLogoImage(uri);
    setLogoFile(normalizedFile);
  };

  const removeLogo = () => {
    setLogoImage(null);
    setLogoFile(null);
    setEditingDealer((prev: DealerItem | null) =>
      prev ? ({ ...prev, logoUrl: null } as DealerItem) : prev,
    );
  };

  const handleSubmit = async () => {
    if (!editingDealer?.dealerName || editingDealer.dealerName.trim() === '') {
      SnackBar.Error(t('dealers.messages.dealerNameRequired'));
      return;
    }

    try {
      setSaving(true);
      setErrorMessage(null);

      let dealerId = editingDealer.id;
      const dealerPayload = { ...editingDealer } as any;

      if (dealerPayload.logoUrl === undefined) {
        delete dealerPayload.logoUrl;
      }

      if (dealerPayload.logoUrl === null) {
        dealerPayload.clearLogoUrl = true;
        delete dealerPayload.logoUrl;
      }

      if (dealerId) {
        await service.updateDealer(dealerPayload as DealerItem);
      } else {
        const createdDealer = await service.createDealer(dealerPayload);
        dealerId = createdDealer.id;
      }

      if (logoFile && dealerId) {
        await service.uploadDealerLogo(dealerId, logoFile);
      }

      SnackBar.Success(
        t(editingDealer.id ? 'dealers.messages.updated' : 'dealers.messages.created', {
          name: editingDealer.dealerName,
        }),
      );
      await loadDealers(1, false, false);
      closeModal();
    } catch (error: any) {
      SnackBar.Error(error?.message || t('dealers.messages.unableSave'));
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = (dealer: DealerItem) => {
    RNAlert.alert(
      t('dealers.messages.deleteTitle'),
      t('dealers.messages.deleteConfirmation', { name: dealer.dealerName }),
      [
        { text: t('dealers.actions.cancel'), style: 'cancel' },
        {
          text: t('dealers.actions.delete'),
          style: 'destructive',
          onPress: () => handleDelete(dealer),
        },
      ],
    );
  };

  const handleDelete = async (dealer: DealerItem) => {
    try {
      await service.deleteDealer(dealer.id);
      SnackBar.Success(t('dealers.messages.deleted', { name: dealer.dealerName }));
      await loadDealers(1, false, false);
    } catch (error: any) {
      SnackBar.Error(
        error?.message || t('dealers.messages.deleteFailed', { name: dealer.dealerName }),
      );
    }
  };

  return (
    <SafeAreaView className="bg-background" style={styles.page}>
      <StatusBar />

      <View
        className="bg-background border-b border-border"
        style={styles.headerBar}
      >
        <Button
          variant="ghost"
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <Icon as={ChevronLeft} size={22} className="text-foreground" />
        </Button>
        <Text className="text-foreground" style={styles.headerTitle}>
          {t('dealers.list.title')}
        </Text>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t('dealers.accessibility.newDealer')}
          onPress={() => router.push('/dealers/new')}
          disabled={permissionState !== 'authorized'}
          style={[styles.addButton, { backgroundColor: theme.primary }]}
        >
          <Plus size={18} color={theme.primaryForeground} />
        </Pressable>
      </View>

      {permissionState === 'checking' ? (
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color={theme.primary} />
          <Text className="text-muted-foreground" style={styles.stateText}>{t('dealers.dashboard.checkingPermission')}</Text>
        </View>
      ) : permissionState === 'denied' ? (
        <UnauthorizedView title={t('dealers.unauthorized.title')} message={t('dealers.unauthorized.description')} />
      ) : (
      <KeyboardAwareScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={theme.primary}
          />
        }
        onScroll={handleScroll}
        scrollEventThrottle={400}
      >
        {loading && !refreshing ? (
          <View style={styles.centeredState}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text className="text-muted-foreground" style={styles.stateText}>
              {t('dealers.list.loading')}
            </Text>
          </View>
        ) : dealers.length === 0 ? (
          <View style={styles.centeredState}>
            <Text className="text-foreground" style={styles.stateTitle}>
              {t('dealers.empty.noDealers')}
            </Text>
            <Text className="text-muted-foreground" style={styles.stateText}>
              {t('dealers.empty.addDealer')}
            </Text>
          </View>
        ) : (
          <>
            <View style={[styles.tableHeader, { backgroundColor: theme.muted, borderColor: theme.border }]}>
              <Text
                style={[styles.headerCell, styles.headerInfo]}
              >{t('dealers.list.totalHeader', { count: dealers.length, more: hasMore ? '+' : '' })}</Text>
              <Text style={[styles.headerCell, styles.statusColumn]}>
                {t('dealers.fields.status')}
              </Text>
              <View style={styles.headerChevronSpace} />
            </View>
            {dealers.map((dealer) => {
              const detail =
                [dealer.phoneNumber, dealer.city].filter(Boolean).join(' · ') ||
                dealer.email ||
                '';
              return (
                <Pressable
                  key={dealer.id}
                  accessibilityRole="button"
                  accessibilityLabel={t('dealers.accessibility.dealer', { name: dealer.dealerName })}
                  style={[styles.row, { borderBottomColor: theme.border, backgroundColor: theme.card }]}
                  onPress={() =>
                    router.push({
                      pathname: '/dealers/view',
                      params: { id: dealer.id },
                    })
                  }
                >
                  <View style={[styles.logoWrapper, { backgroundColor: theme.muted }]}>
                    {dealer.logoUrl ? (
                      <Image
                        source={{ uri: dealer.logoUrl }}
                        style={styles.dealerLogo}
                        resizeMode="cover"
                      />
                    ) : (
                      <View style={[styles.logoPlaceholder, { backgroundColor: theme.secondary }]}>
                        <Icon
                          as={ImageIcon}
                          size={18}
                          className="text-muted-foreground"
                        />
                      </View>
                    )}
                  </View>

                  <View style={styles.infoColumn}>
                    <Text
                      className="text-foreground"
                      style={styles.dealerName}
                      numberOfLines={1}
                    >
                      {dealer.dealerName}
                    </Text>
                    {detail ? (
                      <Text
                        className="text-muted-foreground"
                        style={styles.dealerDetail}
                        numberOfLines={1}
                      >
                        {detail}
                      </Text>
                    ) : null}
                  </View>

                  <View style={styles.statusColumn}>
                    <View
                      style={[
                        styles.statusPill,
                        { backgroundColor: theme.secondary },
                      ]}
                    >
                      <Text
                        style={[
                          styles.statusText,
                          { color: dealer.isActive ? theme.chart2 : theme.destructive },
                        ]}
                      >
                        {dealer.isActive ? t('dealers.labels.active') : t('dealers.labels.inactive')}
                      </Text>
                    </View>
                  </View>

                  <Icon
                    as={ChevronRight}
                    size={16}
                    className="text-muted-foreground"
                  />
                </Pressable>
              );
            })}
          </>
        )}
        {loadingMore ? (
          <View style={styles.loadMoreRow}>
            <ActivityIndicator size="small" color={theme.primary} />
            <Text className="text-muted-foreground" style={styles.loadMoreText}>
              {t('dealers.list.loadingMore')}
            </Text>
          </View>
        ) : null}
      </KeyboardAwareScrollView>
      )}

      <Modal
        visible={modalVisible}
        transparent
        animationType="slide"
        onRequestClose={closeModal}
      >
        <View style={[styles.modalOverlay, { backgroundColor: theme.overlay }]}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 40 : 0}
            style={[styles.modalSheet, { backgroundColor: theme.card, borderColor: theme.border }]}
          >
            <ScrollView
              contentContainerStyle={styles.modalScrollContent}
              keyboardShouldPersistTaps="handled"
              automaticallyAdjustKeyboardInsets={true}
              showsVerticalScrollIndicator={true}
            >
              <View style={styles.modalHeader}>
                <Text variant="h4" className="text-foreground">
                  {editingDealer?.id ? t('dealers.actions.editDealer') : t('dealers.actions.addDealer')}
                </Text>
                <Pressable onPress={closeModal} style={styles.closeButton}>
                  <Icon as={X} size={20} color={theme.mutedForeground} />
                </Pressable>
              </View>

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.dealerName')}
              </Label>
              <Input
                placeholder={t('dealers.placeholders.dealerName')}
                value={editingDealer?.dealerName}
                onChangeText={(text) =>
                  setEditingDealer(
                    (prev: DealerItem | null) =>
                      ({ ...prev, dealerName: text }) as DealerItem,
                  )
                }
                autoCapitalize="words"
                style={styles.input}
              />

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.email')}
              </Label>
              <Input
                placeholder={t('dealers.placeholders.email')}
                value={editingDealer?.email}
                onChangeText={(text) =>
                  setEditingDealer(
                    (prev: DealerItem | null) =>
                      ({ ...prev, email: text }) as DealerItem,
                  )
                }
                keyboardType="email-address"
                style={styles.input}
              />

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.phone')}
              </Label>
              <Input
                placeholder={t('dealers.placeholders.phone')}
                value={editingDealer?.phoneNumber}
                onChangeText={(text) =>
                  setEditingDealer(
                    (prev: DealerItem | null) =>
                      ({ ...prev, phoneNumber: text }) as DealerItem,
                  )
                }
                keyboardType="phone-pad"
                style={styles.input}
              />

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.address')}
              </Label>
              <Input
                placeholder={t('dealers.placeholders.address')}
                value={editingDealer?.address}
                onChangeText={(text) =>
                  setEditingDealer(
                    (prev: DealerItem | null) =>
                      ({ ...prev, address: text }) as DealerItem,
                  )
                }
                style={styles.input}
              />

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.stateDivision')}
              </Label>
              <Input
                placeholder={t('dealers.placeholders.stateDivision')}
                value={editingDealer?.stateDivision}
                onChangeText={(text) =>
                  setEditingDealer(
                    (prev: DealerItem | null) =>
                      ({ ...prev, stateDivision: text }) as DealerItem,
                  )
                }
                style={styles.input}
              />

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.city')}
              </Label>
              <Input
                placeholder={t('dealers.placeholders.city')}
                value={editingDealer?.city}
                onChangeText={(text) =>
                  setEditingDealer(
                    (prev: DealerItem | null) =>
                      ({ ...prev, city: text }) as DealerItem,
                  )
                }
                style={styles.input}
              />

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.country')}
              </Label>
              <Input
                placeholder={t('dealers.placeholders.country')}
                value={editingDealer?.country}
                onChangeText={(text) =>
                  setEditingDealer(
                    (prev: DealerItem | null) =>
                      ({ ...prev, country: text }) as DealerItem,
                  )
                }
                style={styles.input}
              />

              <Label className="text-foreground" style={styles.label}>
                {t('dealers.fields.dealerLogo')}
              </Label>
              {logoImage ? (
                <View style={[styles.logoPreviewContainer, { borderColor: theme.border }]}>
                  <Image
                    source={{ uri: logoImage }}
                    style={styles.logoPreview}
                    resizeMode="cover"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onPress={removeLogo}
                    style={styles.removeLogoButton}
                  >
                    <Text className="text-destructive">{t('dealers.actions.remove')}</Text>
                  </Button>
                </View>
              ) : null}
              <Button
                variant="outline"
                size="sm"
                onPress={pickLogo}
                style={styles.pickerButton}
              >
                <Text className="text-foreground">
                  {logoImage ? t('dealers.actions.changeLogo') : t('dealers.actions.chooseLogo')}
                </Text>
              </Button>

              <View style={styles.switchRow}>
                <Text className="text-foreground" style={styles.switchLabel}>
                  {t('dealers.fields.isActive')}
                </Text>
                  <Switch
                  value={editingDealer?.isActive}
                  onValueChange={(value) =>
                    setEditingDealer(
                      (prev: DealerItem | null) =>
                        ({ ...prev, isActive: value }) as DealerItem,
                    )
                  }
                    trackColor={{ false: theme.muted, true: theme.primary }}
                    thumbColor={theme.card}
                  />
              </View>

              <View style={styles.modalActions}>
                <Button
                  variant="outline"
                  size="sm"
                  onPress={closeModal}
                  style={styles.modalButton}
                >
                  <Text className="text-foreground">{t('dealers.actions.cancel')}</Text>
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onPress={handleSubmit}
                  disabled={saving}
                  style={[styles.modalButton, { backgroundColor: theme.primary }]}
                >
                  {saving ? (
                    <ActivityIndicator size="small" color={theme.primaryForeground} />
                  ) : (
                    <Text style={{ color: theme.primaryForeground }}>{t('dealers.actions.save')}</Text>
                  )}
                </Button>
              </View>
            </ScrollView>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
  },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  backButton: {
    minWidth: 44,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '700',
  },
  addButton: {
    width: 34,
    height: 34,
    marginHorizontal: 5,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    paddingBottom: 24,
  },
  tableHeader: {
    minHeight: 34,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderBottomWidth: 1,
  },
  headerCell: {
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  headerInfo: {
    flex: 1,
    paddingLeft: 56,
  },
  headerChevronSpace: {
    width: 16,
  },
  row: {
    minHeight: 76,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  logoWrapper: {
    width: 44,
    height: 44,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  dealerLogo: {
    width: '100%',
    height: '100%',
  },
  logoPlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  infoColumn: {
    flex: 1,
    minWidth: 0,
    gap: 4,
  },
  dealerName: {
    fontSize: 15,
    fontWeight: '700',
  },
  dealerDetail: {
    fontSize: 12,
  },
  statusColumn: {
    width: 88,
    alignItems: 'flex-start',
  },
  statusPill: {
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  statusText: {
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.4,
  },
  centeredState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 48,
  },
  stateTitle: {
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 6,
  },
  stateText: {
    fontSize: 13,
    textAlign: 'center',
    marginTop: 6,
  },
  loadMoreText: {
    fontSize: 12,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingTop: 60, // Preserves status bar gap
  },
  modalSheet: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '95%', // Prevents sheet from expanding off-screen
    overflow: 'hidden',
  },
  modalScrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 32, // Ensures bottom buttons are fully visible above keyboard
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  closeButton: {
    padding: 4,
  },
  label: {
    marginBottom: 8,
  },
  input: {
    marginBottom: 8,
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingVertical: 4,
  },
  switchLabel: {
    fontSize: 14,
    fontWeight: '500',
  },
  loadMoreRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
  },
  logoPreviewContainer: {
    marginBottom: 12,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
  },
  logoPreview: {
    width: '100%',
    height: 140,
  },
  removeLogoButton: {
    marginTop: 8,
  },
  pickerButton: {
    marginBottom: 12,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
    marginTop: 16,
  },
  modalButton: {
    minWidth: 96,
  },
});
