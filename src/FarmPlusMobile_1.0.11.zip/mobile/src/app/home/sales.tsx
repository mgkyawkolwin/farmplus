'use client';

import * as React from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';

import HomeTopBar from '@/components/homeTopBar';
import { SalesDashboardContent } from '@/components/sales-dashboard';

export default function SalesScreen() {
  return (
    <SafeAreaView className="bg-background" style={{ flex: 1 }}>
      <HomeTopBar />
      <SalesDashboardContent showHeader={false} />
    </SafeAreaView>
  );
}