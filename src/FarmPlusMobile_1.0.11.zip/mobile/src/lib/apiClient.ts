import * as SecureStore from 'expo-secure-store';
import { router } from 'expo-router';
import CustomError from './customError';
import ApiResponse from '@/models/apiResponse'
import { clearTokens, getSelectedShopId, getToken } from '@/lib/authStorage';

//const DEFAULT_API_BASE_URL = 'http://10.229.167.26:5555/api';
 const DEFAULT_API_BASE_URL = 'https://posapi.farmplus.app/api';
// const DEFAULT_API_BASE_URL = process.env.EXPO_PUBLIC_API_URL;
export const API_BASE_URL = DEFAULT_API_BASE_URL;
const AUTH_USER_STORAGE_KEY = 'auth_user';

export async function fetchJson(path: string, options: RequestInit = {}): Promise<ApiResponse<any>> {
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string>),
  };

  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers,
    ...options,
  });

  // Handle 401 Unauthorized response - token is invalid/expired
  if (response.status === 401) {
    await clearTokens();
    router.replace('/auth/signin');
  }

  if (!response.ok) {
        throw new CustomError(`Invalid response ${response.status} - ${response.statusText}. Please try again.`);
  }

  const responseJson = await response.json() as unknown as ApiResponse<any>;

  if (!responseJson.success){
    throw new CustomError(responseJson.message);
  }

  return responseJson;
}

export async function authenticatedFetchJson(path: string, options: RequestInit = {}): Promise<ApiResponse<any>> {
  const token = await getToken();
  const shopId = await getSelectedShopId();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string>),
  };

  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  // Stock, purchases and sales are scoped to the shop chosen in the top bar.
  if (shopId) {
    headers['X-Shop-Id'] = shopId;
  }

  const response = await fetchJson(path, { ...options, headers });

  return response;
}

export async function fetchApi(path: string, options: RequestInit = {}): Promise<ApiResponse<any>> {
  return fetchJson(path, options);
}

export async function authenticatedFetchApi(path: string, options: RequestInit = {}): Promise<ApiResponse<any>> {
  return authenticatedFetchJson(path, options);
}
