import { authenticatedFetchApi } from '@/lib/apiClient';
import { DealerItem, DealerListPayload } from '@/models/dealer';
import { CustomerPayment, CustomerPaymentListPayload } from '@/models/customer';
import { Sale, SaleListPayload } from '@/models/sale';

export interface IDealerService {
  getDealers(page?: number, pageSize?: number): Promise<DealerItem[]>;
  getDealerById(id: string): Promise<DealerItem>;
  getDealerSales(id: string, page?: number, pageSize?: number): Promise<Sale[]>;
  getDealerPayments(id: string, page?: number, pageSize?: number): Promise<CustomerPayment[]>;
  createDealer(request: Partial<DealerItem>): Promise<DealerItem>;
  updateDealer(request: DealerItem): Promise<DealerItem>;
  uploadDealerLogo(id: string, file: { uri: string; name: string; type: string }): Promise<DealerItem>;
  deleteDealer(id: string): Promise<void>;
}

export class DealerServiceClient implements IDealerService {
  async getDealers(page = 1, pageSize = 50): Promise<DealerItem[]> {
    const response = await authenticatedFetchApi(`/dealers?page=${page}&pageSize=${pageSize}`, {
      method: 'GET',
    });

    const payload = response.data as DealerListPayload | undefined;
    return Array.isArray(payload?.items) ? payload.items.map(mapDealer) : [];
  }

  async getDealerById(id: string): Promise<DealerItem> {
    const response = await authenticatedFetchApi(`/dealers/${id}`, {
      method: 'GET',
    });

    return mapDealer(response.data as DealerItem | undefined);
  }

  async getDealerSales(id: string, page = 1, pageSize = 20): Promise<Sale[]> {
    const response = await authenticatedFetchApi(
      `/dealers/${id}/sales?page=${page}&pageSize=${pageSize}`,
      { method: 'GET' },
    );
    const payload = response.data as SaleListPayload | undefined;
    return Array.isArray(payload?.items) ? payload.items : [];
  }

  async getDealerPayments(id: string, page = 1, pageSize = 20): Promise<CustomerPayment[]> {
    const response = await authenticatedFetchApi(
      `/dealers/${id}/payments?page=${page}&pageSize=${pageSize}`,
      { method: 'GET' },
    );
    const payload = response.data as CustomerPaymentListPayload | undefined;
    return Array.isArray(payload?.items) ? payload.items : [];
  }

  async createDealer(request: Partial<DealerItem>): Promise<DealerItem> {
    const response = await authenticatedFetchApi('/dealers', {
      method: 'POST',
      body: JSON.stringify(request),
    });

    return mapDealer(response.data as DealerItem | undefined);
  }

  async updateDealer(request: DealerItem): Promise<DealerItem> {
    const response = await authenticatedFetchApi(`/dealers/${request.id}`, {
      method: 'PUT',
      body: JSON.stringify(request),
    });

    return mapDealer(response.data as DealerItem | undefined);
  }

  async uploadDealerLogo(id: string, file: { uri: string; name: string; type: string }): Promise<DealerItem> {
    const formData = new FormData();
    formData.append('file', { uri: file.uri, name: file.name, type: file.type } as any);

    const response = await authenticatedFetchApi(`/dealers/${id}/logo`, {
      method: 'PATCH',
      body: formData,
    });

    return mapDealer(response.data as DealerItem | undefined);
  }

  async deleteDealer(id: string): Promise<void> {
    await authenticatedFetchApi(`/dealers/${id}`, {
      method: 'DELETE',
    });
  }
}

function mapDealer(item?: Partial<DealerItem> | null): DealerItem {
  return {
    id: item?.id ?? '',
    dealerName: item?.dealerName ?? '',
    email: item?.email,
    phoneNumber: item?.phoneNumber,
    address: item?.address,
    stateDivision: item?.stateDivision,
    city: item?.city,
    country: item?.country,
    logoUrl: item?.logoUrl,
    isActive: item?.isActive ?? false,
    totalOrders: item?.totalOrders,
    totalSales: item?.totalSales,
    totalPaid: item?.totalPaid,
    totalOutstanding: item?.totalOutstanding,
    recentSales: item?.recentSales,
    recentPayments: item?.recentPayments,
    rowVersion: item?.rowVersion,
    createdAtUtc: item?.createdAtUtc,
    updatedAtUtc: item?.updatedAtUtc,
  };
}
