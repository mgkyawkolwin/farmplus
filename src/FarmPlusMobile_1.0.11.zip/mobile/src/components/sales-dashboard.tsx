'use client';

import * as React from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { useFocusEffect, usePathname, useRouter } from 'expo-router';
import { useColorScheme } from 'nativewind';
import { CalendarDays, ChevronLeft, ChevronRight, CirclePlus, ClipboardList, ContactRound, Package, ReceiptText, TrendingUp, Wallet } from 'lucide-react-native';

import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { Text } from '@/components/ui/text';
import UnauthorizedView from '@/components/unauthorized-view';
import LoadingOverlay from '@/components/loadingOverlay';
import SnackBar from '@/components/ui/snack-bar';
import { container, DI_TOKENS } from '@/di';
import { Sale, SaleDashboard } from '@/models/sale';
import { ISaleService } from '@/services/saleService';
import { useSelectedShopChanged } from '@/lib/selectedShop';
import { RolePermissionServiceClient } from '@/services/rolePermissionService';
import { THEME } from '@/lib/theme';
import { useTranslation } from 'react-i18next';

const saleService = container.resolve<ISaleService>(DI_TOKENS.ISaleService);
const permissionService = new RolePermissionServiceClient();

function money(value: number) {
  return `${value.toLocaleString('en-US', { maximumFractionDigits: 2 })} MMK`;
}

type ThemeColors = typeof THEME.light;
type MetricTone = 'green' | 'blue' | 'amber' | 'red';

function getToneColor(tone: MetricTone, theme: ThemeColors) {
  switch (tone) {
    case 'green': return theme.chart2;
    case 'blue': return theme.chart1;
    case 'amber': return theme.chart4;
    case 'red': return theme.destructive;
  }
}

function Metric({
  label,
  value,
  icon,
  tone,
  theme,
}: {
  label: string;
  value: string;
  icon: typeof TrendingUp;
  tone: MetricTone;
  theme: ThemeColors;
}) {
  const MetricIcon = icon;
  const toneColor = getToneColor(tone, theme);

  return (
    <View style={[styles.metricCard, { backgroundColor: theme.secondary, borderColor: theme.border, borderTopColor: toneColor }]}>
      <View style={styles.metricHeader}>
        <View style={[styles.metricIcon, { backgroundColor: theme.card }]}>
          <MetricIcon size={16} color={toneColor} />
        </View>
        <Text style={[styles.metricLabel, { color: theme.mutedForeground }]} numberOfLines={1}>{label}</Text>
      </View>
      <Text style={[styles.metricValue, { color: theme.foreground }]} numberOfLines={1} adjustsFontSizeToFit>{value}</Text>
    </View>
  );
}

function getPaymentStatus(sale: Sale, t: (key: string) => string) {
  if (sale.status === 'Voided') return { label: t('sales.status.void'), color: '#B91C1C', bg: '#FEE2E2' };
  if (sale.paidAmount > 0 && sale.balance <= 0) return { label: t('sales.status.paid'), color: '#047857', bg: '#D1FAE5' };
  return { label: t('sales.status.unpaid'), color: '#B45309', bg: '#FEF3C7' };
}

function RecentSaleRow({ sale, t }: { sale: Sale; t: (key: string) => string }) {
  const status = getPaymentStatus(sale, t);
  return (
    <View style={styles.saleRow}>
      <View style={styles.customerCell}>
        <Text className="text-foreground" style={styles.customerName} numberOfLines={1}>{sale.customerName}</Text>
        <View style={styles.dateRow}>
          <Icon className="text-muted-foreground" as={CalendarDays} size={12} />
          <Text className="text-muted-foreground" style={styles.saleDate}>{new Date(sale.saleDate).toLocaleDateString()}</Text>
          <View style={[styles.statusPill, { backgroundColor: status.bg }]}>
            <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
          </View>
        </View>
      </View>
      <Text className="text-muted-foreground" style={styles.productCount}>{sale.totalProducts}</Text>
      <Text className="text-foreground" style={styles.saleTotal} numberOfLines={1}>{money(sale.netTotal)}</Text>
    </View>
  );
}

export function SalesDashboardContent({
  showHeader = true,
  title,
  onBack,
}: {
  showHeader?: boolean;
  title?: string;
  onBack?: () => void;
}) {
  const router = useRouter();
  const { t } = useTranslation();
  const { colorScheme } = useColorScheme() ?? { colorScheme: 'light' };
  const theme = colorScheme === 'dark' ? THEME.dark : THEME.light;
  const pathname = usePathname();
  const permissionKey = pathname === '/home/sales' ? '/home/sales' : '/sales/dashboard';
  const [dashboard, setDashboard] = React.useState<SaleDashboard | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);
  const [permissionState, setPermissionState] = React.useState<'checking' | 'authorized' | 'denied'>('checking');

  useFocusEffect(
    React.useCallback(() => {
      let active = true;
      setPermissionState('checking');
      permissionService.getCurrentPermissions().then((permissions) => {
        if (!active) return;
        setPermissionState(
          permissions.isExempt || permissions.permissionKeys.includes(permissionKey)
            ? 'authorized'
            : 'denied',
        );
      }).catch(() => {
        if (active) setPermissionState('denied');
      });
      return () => { active = false; };
    }, [permissionKey]),
  );

  const loadDashboard = React.useCallback(async () => {
    try {
      setDashboard(await saleService.getDashboard());
    } catch (error) {
      SnackBar.Error(error instanceof Error ? error.message : t('sales.messages.unableLoadDashboard'));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [t]);

  useFocusEffect(
    React.useCallback(() => {
      if (permissionState !== 'authorized') return undefined;
      setLoading(true);
      void loadDashboard();
      return undefined;
    }, [loadDashboard, permissionState]),
  );

  useSelectedShopChanged(() => {
    if (permissionState !== 'authorized') return;
    void loadDashboard();
  });

  if (permissionState === 'checking') {
    return (
      <View style={styles.page}>
        {showHeader ? (
          <View className="bg-background border-b border-border" style={styles.headerBar}>
            <Button variant="ghost" onPress={onBack ?? (() => router.back())} style={styles.headerButton}>
              <Icon className="text-foreground" as={ChevronLeft} size={22} />
            </Button>
            <Text className="text-foreground" style={styles.headerTitle}>{title ?? t('sales.dashboard.title')}</Text>
            <View style={styles.headerButton} />
          </View>
        ) : null}
        <View style={styles.accessState}>
          <ActivityIndicator size="large" color="#16794B" />
          <Text className="text-muted-foreground" style={styles.accessText}>{t('sales.dashboard.loadingPermission')}</Text>
        </View>
      </View>
    );
  }

  if (permissionState === 'denied') {
    return (
      <View style={styles.page}>
        {showHeader ? (
          <View className="bg-background border-b border-border" style={styles.headerBar}>
            <Button variant="ghost" onPress={onBack ?? (() => router.back())} style={styles.headerButton}>
              <Icon className="text-foreground" as={ChevronLeft} size={22} />
            </Button>
            <Text className="text-foreground" style={styles.headerTitle}>{title ?? t('sales.dashboard.title')}</Text>
            <View style={styles.headerButton} />
          </View>
        ) : null}
        <UnauthorizedView title={t('sales.unauthorized.title')} message={t('sales.unauthorized.description')} />
      </View>
    );
  }

  return (
    <View style={styles.page}>
      <LoadingOverlay isLoading={loading && dashboard !== null} />
      {showHeader ? (
        <View className="bg-background border-b border-border" style={styles.headerBar}>
          <Button variant="ghost" onPress={onBack ?? (() => router.back())} style={styles.headerButton}>
            <Icon className="text-foreground" as={ChevronLeft} size={22} />
          </Button>
          <Text className="text-foreground" style={styles.headerTitle}>{title ?? t('sales.dashboard.title')}</Text>
          <View style={styles.headerButton} />
        </View>
      ) : null}

      {loading && !dashboard ? (
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#16794B" />
          <Text className="text-muted-foreground" style={styles.stateText}>{t('sales.dashboard.loading')}</Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={styles.content}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => {
            setRefreshing(true);
            void loadDashboard();
          }} />}
        >
          <View style={styles.metricsGrid}>
            <Metric label={t('sales.dashboard.today')} value={money(dashboard?.todaySales ?? 0)} icon={Wallet} tone="green" theme={theme} />
            <Metric label={t('sales.dashboard.thisMonth')} value={money(dashboard?.thisMonthSales ?? 0)} icon={TrendingUp} tone="blue" theme={theme} />
            <Metric label={t('sales.dashboard.totalUnpaidSales')} value={(dashboard?.unpaidSales ?? 0).toLocaleString('en-US')} icon={ReceiptText} tone="red" theme={theme} />
            <Metric label={t('sales.dashboard.totalUnpaidAmount')} value={money(dashboard?.unpaidAmount ?? 0)} icon={Wallet} tone="red" theme={theme} />
            <Metric label={t('sales.dashboard.totalProducts')} value={(dashboard?.totalProducts ?? 0).toLocaleString('en-US')} icon={Package} tone="amber" theme={theme} />
            <Metric label={t('sales.dashboard.totalCustomers')} value={(dashboard?.totalCustomers ?? 0).toLocaleString('en-US')} icon={ContactRound} tone="blue" theme={theme} />
          </View>

          <View style={styles.actionRow}>
            <Button
              style={[styles.actionButton, styles.actionPrimary]}
              onPress={() => router.push('/sales/new' as Parameters<typeof router.push>[0])}
            >
              <CirclePlus size={18} color="#FFFFFF" />
              <Text style={[styles.actionLabel, styles.actionPrimaryLabel]}>{t('sales.dashboard.newSale')}</Text>
            </Button>
            <Button
              variant="outline"
              style={[styles.actionButton, styles.actionSecondary]}
              onPress={() => router.push('/sales/list' as Parameters<typeof router.push>[0])}
            >
              <ClipboardList size={18} color="#16794B" />
              <Text style={[styles.actionLabel, styles.actionSecondaryLabel]}>{t('sales.dashboard.viewSales')}</Text>
            </Button>
          </View>

          <View style={styles.recentSection}>
            <View style={styles.sectionHeading}>
              <View>
                <Text className="text-foreground" style={styles.sectionTitle}>{t('sales.dashboard.recentSales')}</Text>
              </View>
              <Button
                variant="ghost"
                style={styles.seeAllButton}
                onPress={() => router.push('/sales/list' as Parameters<typeof router.push>[0])}
              >
                <Text style={styles.seeAllText}>{t('sales.dashboard.viewAll')}</Text>
                <ChevronRight size={14} color="#16794B" />
              </Button>
            </View>

            <View style={styles.tableHeader}>
              <Text className="text-muted-foreground" style={[styles.headerCell, styles.customerColumn]}>{t('sales.fields.customerDate')}</Text>
              <Text className="text-muted-foreground" style={[styles.headerCell, styles.qtyColumn]}>{t('sales.fields.quantity')}</Text>
              <Text className="text-muted-foreground" style={[styles.headerCell, styles.totalColumn]}>{t('sales.fields.total')}</Text>
            </View>
            {(dashboard?.recentSales ?? []).length === 0 ? (
              <View style={styles.emptyState}>
                <Text className="text-muted-foreground">{t('sales.dashboard.noSales')}</Text>
              </View>
            ) : dashboard?.recentSales.map((sale) => <RecentSaleRow key={sale.id} sale={sale} t={t} />)}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  accessState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 },
  accessText: { marginTop: 8, textAlign: 'center' },
  headerBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, paddingVertical: 8 },
  headerButton: { minWidth: 44 },
  headerTitle: { flex: 1, textAlign: 'center', fontSize: 18, fontWeight: '600' },
  content: { padding: 16, paddingBottom: 28, gap: 20 },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  metricCard: { width: '48%', minHeight: 88, borderRadius: 6, borderWidth: 1, borderTopWidth: 3, paddingHorizontal: 12, paddingVertical: 10, justifyContent: 'space-between', gap: 10 },
  metricHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  metricIcon: { width: 26, height: 26, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  metricLabel: { flex: 1, fontSize: 10, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.4 },
  metricValue: { fontSize: 18, fontWeight: '800' },
  actionRow: { flexDirection: 'row', gap: 10 },
  actionButton: { flex: 1, minHeight: 46, gap: 8, borderRadius: 6 },
  actionPrimary: { backgroundColor: '#16794B', borderWidth: 1, borderColor: '#16794B' },
  actionSecondary: { backgroundColor: '#F4FAF6', borderWidth: 1, borderColor: '#16794B' },
  actionLabel: { fontSize: 13, fontWeight: '700', letterSpacing: 0.2 },
  actionPrimaryLabel: { color: '#FFFFFF' },
  actionSecondaryLabel: { color: '#16794B' },
  recentSection: { gap: 0 },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  sectionTitle: { fontSize: 15, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.4 },
  sectionSubtitle: { marginTop: 3, fontSize: 11 },
  seeAllButton: { minHeight: 30, paddingHorizontal: 10, paddingVertical: 0, flexDirection: 'row', alignItems: 'center', gap: 2, borderRadius: 999, borderWidth: 1, borderColor: '#CDE8D6', backgroundColor: '#F4FAF6' },
  seeAllText: { fontSize: 11, fontWeight: '700', color: '#16794B', letterSpacing: 0.2 },
  tableHeader: { minHeight: 32, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, backgroundColor: '#F1F5F9', borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#D9DEE5' },
  headerCell: { fontSize: 9, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.5 },
  customerColumn: { flex: 1 },
  qtyColumn: { width: 45, textAlign: 'right' },
  totalColumn: { width: 118, textAlign: 'right' },
  saleRow: { minHeight: 58, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#CBD5E1', gap: 8 },
  customerCell: { flex: 1, gap: 3 },
  customerName: { fontSize: 12, fontWeight: '600' },
  dateRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  saleDate: { fontSize: 10 },
  statusPill: { borderRadius: 999, paddingHorizontal: 7, paddingVertical: 1, marginLeft: 4 },
  statusText: { fontSize: 8.5, fontWeight: '800', letterSpacing: 0.4 },
  productCount: { width: 45, textAlign: 'right', fontSize: 12 },
  saleTotal: { width: 118, textAlign: 'right', fontSize: 12, fontWeight: '700' },
  emptyState: { paddingVertical: 26, alignItems: 'center' },
  centeredState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  stateText: { marginTop: 8 },
});
