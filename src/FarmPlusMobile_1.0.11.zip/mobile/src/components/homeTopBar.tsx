"use client";
import { useFocusEffect, useRouter } from "expo-router";
import React from "react";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  View,
} from "react-native";
import { ThemedStatusBar as StatusBar } from "@/components/themed-status-bar";
import { Text } from "@/components/ui/text";
import { Button } from "./ui/button";
import {
  Bell,
  Check,
  ChevronDown,
  Menu,
  Settings,
  Store,
  User,
  X,
} from "lucide-react-native";
import { Icon } from "@/components/ui/icon";
import SnackBar from "@/components/ui/snack-bar";
import { Shop } from "@/models/shop";
import { ShopServiceClient } from "@/services/shopService";
import {
  clearSelectedShopId,
  getSelectedShopId,
  storeSelectedShopId,
} from "@/lib/authStorage";
import { notifySelectedShopChanged } from "@/lib/selectedShop";
import { MessageServiceClient } from "@/services/messageService";
import { useTranslation } from "react-i18next";
import { useColorScheme } from "nativewind";
import { THEME } from "@/lib/theme";

const shopService = new ShopServiceClient();
const messageService = new MessageServiceClient();
const UNREAD_POLL_INTERVAL_MS = 10_000;

export default function HomeTopBar() {
  const router = useRouter();
  const { t } = useTranslation();
  const { colorScheme } = useColorScheme() ?? { colorScheme: "light" };
  const theme = colorScheme === "dark" ? THEME.dark : THEME.light;

  const [shops, setShops] = React.useState<Shop[]>([]);
  const [selectedShopId, setSelectedShopId] = React.useState<string | null>(
    null,
  );
  const [pickerVisible, setPickerVisible] = React.useState(false);
  const [loadingShops, setLoadingShops] = React.useState(false);
  const [unreadCount, setUnreadCount] = React.useState(0);

  useFocusEffect(
    React.useCallback(() => {
      let active = true;
      let isFetching = false;
      const refreshUnreadCount = async () => {
        if (isFetching) return;
        isFetching = true;
        try {
          const count = await messageService.getUnreadCount();
          if (active) setUnreadCount(count);
        } catch {
          // Keep the last known count when the network is temporarily unavailable.
        } finally {
          isFetching = false;
        }
      };

      void refreshUnreadCount();
      const intervalId = setInterval(() => void refreshUnreadCount(), UNREAD_POLL_INTERVAL_MS);
      return () => {
        active = false;
        clearInterval(intervalId);
      };
    }, []),
  );

  const loadShops = React.useCallback(async (showError = false) => {
    setLoadingShops(true);
    try {
      const storedId = await getSelectedShopId();
      const result = await shopService.getShops(1, 200);
      setShops(result);

      if (result.length === 0) {
        setSelectedShopId(null);
        if (storedId) {
          await clearSelectedShopId();
          notifySelectedShopChanged();
        }
        SnackBar.Error(t("shops.setupRequired"));
        router.push("/shops/shops" as Parameters<typeof router.push>[0]);
        return;
      }

      // Keep the stored shop when it still exists; otherwise default to the first shop.
      const validStoredId =
        storedId && result.some((shop) => shop.id === storedId) ? storedId : null;
      const nextShopId = validStoredId ?? result[0].id;
      setSelectedShopId(nextShopId);

      if (nextShopId !== storedId) {
        await storeSelectedShopId(nextShopId);
        notifySelectedShopChanged();
      }
    } catch (error) {
      if (showError) {
        SnackBar.Error(
          error instanceof Error ? error.message : "Unable to load shops",
        );
      }
    } finally {
      setLoadingShops(false);
    }
  }, [router, t]);

  useFocusEffect(
    React.useCallback(() => {
      void loadShops(false);
    }, [loadShops]),
  );

  const openPicker = () => {
    setPickerVisible(true);
    void loadShops(true);
  };

  const selectShop = async (shop: Shop) => {
    setSelectedShopId(shop.id);
    setPickerVisible(false);
    try {
      await storeSelectedShopId(shop.id);
      notifySelectedShopChanged();
    } catch {
      SnackBar.Error("Unable to save the selected shop");
    }
  };

  const selectedShop = shops.find((shop) => shop.id === selectedShopId);

  return (
    <View className="bg-tab" style={styles.container}>
      <StatusBar backgroundColor="#FFFFFF" barStyle="dark-content" />
      <View className="bg-red border-border" style={styles.headerBar}>
        <View style={styles.leftSection}>
          <Button
            variant="ghost"
            onPress={() => router.push("/profile")}
            style={styles.iconButton}
          >
            <Icon className="text-foreground" as={User} size={22} />
          </Button>
          <Button
            variant="ghost"
            onPress={() => router.push("/menu")}
            style={styles.iconButton}
          >
            <Icon className="text-foreground" as={Menu} size={22} />
          </Button>

          <Pressable
            onPress={openPicker}
            style={styles.selectTrigger}
            className="border-input bg-card"
            accessibilityRole="button"
            accessibilityLabel="Choose shop"
          >
            <Icon className="text-muted-foreground" as={Store} size={15} />
            <Text
              className={selectedShop ? "text-foreground" : "text-muted-foreground"}
              style={[
                styles.selectText,
                !selectedShop && styles.selectPlaceholder,
              ]}
              numberOfLines={1}
            >
              {selectedShop ? selectedShop.name : "Select shop"}
            </Text>
            <Icon className="text-muted-foreground" as={ChevronDown} size={16} />
          </Pressable>
        </View>
        <View style={styles.rightSection}>
          <Button
            variant="ghost"
            onPress={() => router.push('/messages/list' as Parameters<typeof router.push>[0])}
            style={styles.iconButton}
            accessibilityLabel={unreadCount > 0 ? `Messages, ${unreadCount} unread` : 'Messages'}
          >
            <View style={styles.notificationButton}>
              <Icon className="text-foreground" as={Bell} size={22} />
              {unreadCount > 0 ? <View style={styles.notificationDot} /> : null}
            </View>
          </Button>

          <Button
            variant="ghost"
            onPress={() => router.push("/settings")}
            style={styles.iconButton}
          >
            <Icon className="text-foreground" as={Settings} size={22} />
          </Button>
        </View>
      </View>

      <Modal
        visible={pickerVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setPickerVisible(false)}
      >
        <View style={styles.modalBackdrop}>
          <Pressable
            style={StyleSheet.absoluteFill}
            onPress={() => setPickerVisible(false)}
          />
          <View className="bg-background" style={styles.sheet}>
              <View className="border-border" style={styles.sheetHeader}>
              <Text className="text-foreground" style={styles.sheetTitle}>
                Select Shop
              </Text>
              <Pressable
                onPress={() => setPickerVisible(false)}
                hitSlop={8}
                accessibilityLabel="Close"
              >
                <Icon className="text-muted-foreground" as={X} size={20} />
              </Pressable>
            </View>

            {loadingShops && shops.length === 0 ? (
              <View style={styles.stateBox}>
                <ActivityIndicator size="small" color={theme.primary} />
                <Text
                  className="text-muted-foreground"
                  style={styles.stateText}
                >
                  Loading shops...
                </Text>
              </View>
            ) : shops.length === 0 ? (
              <View style={styles.stateBox}>
                <Text className="text-foreground" style={styles.stateTitle}>
                  No shops yet
                </Text>
                <Text
                  className="text-muted-foreground"
                  style={styles.stateText}
                >
                  Add a shop to start choosing one here.
                </Text>
                <Button
                  onPress={() => {
                    setPickerVisible(false);
                    router.push(
                      "/shops/shops" as Parameters<typeof router.push>[0],
                    );
                  }}
                  style={styles.manageButton}
                >
                  <Text className="text-primary-foreground" style={styles.manageButtonText}>Manage Shops</Text>
                </Button>
              </View>
            ) : (
              <ScrollView contentContainerStyle={styles.list}>
                {shops.map((shop) => {
                  const selected = shop.id === selectedShopId;
                  const location = [shop.city, shop.stateDivision]
                    .filter(Boolean)
                    .join(" · ");
                  return (
                    <Pressable
                      key={shop.id}
                      onPress={() => void selectShop(shop)}
                      accessibilityRole="button"
                      accessibilityState={{ selected }}
                    >
                      <View
                        className={selected ? "border-border bg-muted" : "border-border"}
                        style={styles.option}
                      >
                        <View
                          className={selected ? "bg-primary" : "bg-muted"}
                          style={styles.tile}
                        >
                          <Icon
                            className={selected ? "text-primary-foreground" : "text-primary"}
                            as={Store}
                            size={16}
                          />
                        </View>
                        <View style={styles.optionInfo}>
                          <Text
                            className="text-foreground"
                            style={styles.optionName}
                            numberOfLines={1}
                          >
                            {shop.name}
                          </Text>
                          {location ? (
                            <Text
                              className="text-muted-foreground"
                              style={styles.optionMeta}
                              numberOfLines={1}
                            >
                              {location}
                            </Text>
                          ) : null}
                        </View>
                        {selected ? <Icon className="text-primary" as={Check} size={18} /> : null}
                      </View>
                    </Pressable>
                  );
                })}
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: 52,
    maxHeight: 52,
    marginBottom: 8,
  },
  headerBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 8,
    paddingTop: 8,
    paddingBottom: 8,
    borderBottomWidth: 1,
    width: "100%",
  },
  leftSection: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    flex: 1,
    minWidth: 0,
  },
  iconButton: {
    maxWidth: 30,
    width: 20,
    padding: 0,
  },
  rightSection: {
    flexDirection: "row",
    alignItems: "center",
    alignContent: "flex-end",
    gap: 8,
  },
  notificationButton: { position: 'relative' },
  notificationDot: {
    position: 'absolute',
    top: -2,
    right: -3,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#B42318',
  },
  selectTrigger: {
    width: 160,
    maxWidth: 160,
    flexShrink: 1,
    height: 36,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderRadius: 6,
  },
  selectText: {
    flex: 1,
    fontSize: 13,
    fontWeight: "600",
  },
  selectPlaceholder: {
    fontWeight: "500",
  },
  modalBackdrop: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.38)",
  },
  sheet: {
    maxHeight: "70%",
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
    paddingTop: 16,
    paddingBottom: 24,
  },
  sheetHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  sheetTitle: {
    fontSize: 15,
    fontWeight: "800",
    textTransform: "uppercase",
    letterSpacing: 0.4,
  },
  list: {
    paddingHorizontal: 12,
    paddingTop: 8,
  },
  option: {
    minHeight: 56,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 8,
    borderRadius: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  tile: {
    width: 34,
    height: 34,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  optionInfo: {
    flex: 1,
    minWidth: 0,
    gap: 2,
  },
  optionName: {
    fontSize: 14,
    fontWeight: "700",
  },
  optionMeta: {
    fontSize: 11,
  },
  stateBox: {
    alignItems: "center",
    paddingVertical: 28,
    paddingHorizontal: 20,
    gap: 8,
  },
  stateTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  stateText: {
    textAlign: "center",
  },
  manageButton: {
    marginTop: 8,
    borderRadius: 6,
  },
  manageButtonText: {
    fontWeight: "700",
  },
  placeholderContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },
});
