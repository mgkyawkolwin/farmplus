'use client';

import * as React from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { useColorScheme } from 'nativewind';
import {
  AlertTriangle,
  Boxes,
  ChevronLeft,
  ChevronRight,
  ClipboardPenLine,
  List,
  Package,
} from 'lucide-react-native';

import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { Text } from '@/components/ui/text';
import LoadingOverlay from '@/components/loadingOverlay';
import UnauthorizedView from '@/components/unauthorized-view';
import SnackBar from '@/components/ui/snack-bar';
import { ProductItem } from '@/models/product';
import { getInventoryProducts } from '@/services/inventoryService';
import { useSelectedShopChanged } from '@/lib/selectedShop';
import { usePagePermission } from '@/lib/usePagePermission';
import { THEME } from '@/lib/theme';
import { useTranslation } from 'react-i18next';

function stockOf(product: ProductItem) {
  return Math.max(0, product.currentStock ?? 0);
}

type ThemeColors = typeof THEME.light;
type MetricTone = 'green' | 'blue' | 'amber' | 'red';

function getToneColor(tone: MetricTone, theme: ThemeColors) {
  switch (tone) {
    case 'green': return theme.chart2;
    case 'blue': return theme.chart1;
    case 'amber': return theme.chart4;
    case 'red': return theme.destructive;
  }
}

function Metric({
  label,
  value,
  icon,
  tone,
  theme,
}: {
  label: string;
  value: string;
  icon: typeof Boxes;
  tone: MetricTone;
  theme: ThemeColors;
}) {
  const MetricIcon = icon;
  const toneColor = getToneColor(tone, theme);

  return (
    <View style={[styles.metricCard, { backgroundColor: theme.secondary, borderColor: theme.border, borderTopColor: toneColor }]}>
      <View style={styles.metricHeader}>
        <View style={[styles.metricIcon, { backgroundColor: theme.card }]}>
          <MetricIcon size={16} color={toneColor} />
        </View>
        <Text style={[styles.metricLabel, { color: theme.mutedForeground }]} numberOfLines={1}>{label}</Text>
      </View>
      <Text style={[styles.metricValue, { color: theme.foreground }]} numberOfLines={1} adjustsFontSizeToFit>{value}</Text>
    </View>
  );
}

export function InventoryDashboardContent({
  showHeader = true,
  title,
  onBack,
}: {
  showHeader?: boolean;
  title?: string;
  onBack?: () => void;
}) {
  const router = useRouter();
  const { t } = useTranslation();
  const { colorScheme } = useColorScheme() ?? { colorScheme: 'light' };
  const theme = colorScheme === 'dark' ? THEME.dark : THEME.light;
  const permissionState = usePagePermission('/inventory/dashboard');
  const [products, setProducts] = React.useState<ProductItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const loadInventory = React.useCallback(async () => {
    try {
      const result = await getInventoryProducts();
      setProducts(result);
    } catch (error) {
      SnackBar.Error(error instanceof Error ? error.message : t('inventory.messages.loadFailed'));
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [t]);

  useFocusEffect(
    React.useCallback(() => {
      if (permissionState !== 'authorized') return undefined;
      setLoading(true);
      void loadInventory();
      return undefined;
    }, [loadInventory, permissionState]),
  );

  useSelectedShopChanged(() => {
    if (permissionState === 'authorized') void loadInventory();
  });

  const totalStock = products.reduce((total, product) => total + stockOf(product), 0);
  const lowStockCount = products.filter((product) => {
    const stock = stockOf(product);
    return stock > 0 && (product.minimumStock ?? 0) > 0 && stock <= (product.minimumStock ?? 0);
  }).length;
  const outOfStockCount = products.filter((product) => stockOf(product) === 0).length;

  const categoryTotals = Array.from(products.reduce((totals, product) => {
    const category = product.category?.trim() || 'Uncategorized';
    totals.set(category, (totals.get(category) ?? 0) + stockOf(product));
    return totals;
  }, new Map<string, number>())).map(([category, quantity]) => ({
    category,
    quantity,
    percentage: totalStock > 0 ? (quantity / totalStock) * 100 : 0,
  })).sort((left, right) => right.quantity - left.quantity);

  return (
    <View style={styles.page}>
      <LoadingOverlay isLoading={loading && products.length > 0} />
      {showHeader ? (
        <View className="bg-background border-b border-border" style={styles.headerBar}>
          <Button variant="ghost" onPress={onBack ?? (() => router.back())} style={styles.headerButton}>
            <Icon className="text-foreground" as={ChevronLeft} size={22} />
          </Button>
          <Text className="text-foreground" style={styles.headerTitle}>{title ?? t('inventory.dashboard.title')}</Text>
          <View style={styles.headerButton} />
        </View>
      ) : null}

      {permissionState === 'checking' ? (
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#16794B" />
          <Text className="text-muted-foreground" style={styles.stateText}>{t('inventory.dashboard.checkingPermission')}</Text>
        </View>
      ) : permissionState === 'denied' ? (
        <UnauthorizedView title={t('inventory.unauthorized.title')} message={t('inventory.unauthorized.description')} />
      ) : loading && products.length === 0 ? (
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color="#16794B" />
          <Text className="text-muted-foreground" style={styles.stateText}>{t('inventory.dashboard.loading')}</Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={styles.content}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={() => {
              setRefreshing(true);
              void loadInventory();
            }} />
          }
        >
          <View style={styles.metricsGrid}>
            <Metric label={t('inventory.dashboard.totalStockQuantity')} value={totalStock.toLocaleString('en-US')} icon={Boxes} tone="green" theme={theme} />
            <Metric label={t('inventory.dashboard.lowStockItems')} value={lowStockCount.toLocaleString('en-US')} icon={AlertTriangle} tone="amber" theme={theme} />
            <Metric label={t('inventory.dashboard.outOfStock')} value={outOfStockCount.toLocaleString('en-US')} icon={Package} tone="red" theme={theme} />
          </View>

          <View style={styles.actionRow}>
            <Button
              style={[styles.actionButton, styles.actionPrimary]}
              onPress={() => router.push('/inventory/adjustment' as Parameters<typeof router.push>[0])}
            >
              <ClipboardPenLine size={18} color="#FFFFFF" />
              <Text style={[styles.actionLabel, styles.actionPrimaryLabel]}>{t('inventory.actions.adjustment')}</Text>
            </Button>
            <Button
              variant="outline"
              style={[styles.actionButton, styles.actionSecondary]}
              onPress={() => router.push('/inventory/list' as Parameters<typeof router.push>[0])}
            >
              <List size={18} color="#16794B" />
              <Text style={[styles.actionLabel, styles.actionSecondaryLabel]}>{t('inventory.actions.stockList')}</Text>
            </Button>
          </View>

          <View style={styles.categorySection}>
            <View style={styles.sectionHeading}>
              <View>
                <Text className="text-foreground" style={styles.sectionTitle}>{t('inventory.dashboard.stockByCategory')}</Text>
              </View>
              <Button
                variant="ghost"
                style={styles.seeAllButton}
                onPress={() => router.push('/inventory/list' as Parameters<typeof router.push>[0])}
              >
                <Text style={styles.seeAllText}>{t('inventory.actions.viewAll')}</Text>
                <ChevronRight size={14} color="#16794B" />
              </Button>
            </View>

            <View style={styles.tableHeader}>
              <Text className="text-muted-foreground" style={[styles.headerCell, styles.categoryColumn]}>{t('inventory.fields.category')}</Text>
              <Text className="text-muted-foreground" style={[styles.headerCell, styles.barColumn]}>{t('inventory.fields.share')}</Text>
              <Text className="text-muted-foreground" style={[styles.headerCell, styles.qtyColumn]}>{t('inventory.fields.quantity')}</Text>
              <Text className="text-muted-foreground" style={[styles.headerCell, styles.percentColumn]}>{t('inventory.fields.percent')}</Text>
            </View>

            {categoryTotals.length === 0 ? (
              <View style={styles.emptyState}>
                <Text className="text-muted-foreground">{t('inventory.dashboard.noCategories')}</Text>
              </View>
            ) : categoryTotals.map((item) => (
              <View key={item.category} style={styles.tableRow}>
                <Text className="text-foreground" style={[styles.categoryText, styles.categoryColumn]} numberOfLines={1}>
                  {item.category === 'Uncategorized' ? t('inventory.empty.noUncategorized') : item.category}
                </Text>
                <View style={[styles.barColumn, styles.progressTrack]}>
                  <View style={[styles.progressFill, { width: `${item.percentage}%` }]} />
                </View>
                <Text className="text-foreground" style={[styles.qtyText, styles.qtyColumn]} numberOfLines={1}>
                  {item.quantity.toLocaleString('en-US')}
                </Text>
                <Text className="text-muted-foreground" style={[styles.percentText, styles.percentColumn]}>
                  {Math.round(item.percentage)}%
                </Text>
              </View>
            ))}
          </View>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  headerBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 12, paddingVertical: 8 },
  headerButton: { minWidth: 44 },
  headerTitle: { flex: 1, textAlign: 'center', fontSize: 18, fontWeight: '600' },
  content: { padding: 16, paddingBottom: 28, gap: 20 },
  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  metricCard: { width: '48%', minHeight: 88, borderRadius: 6, borderWidth: 1, borderTopWidth: 3, paddingHorizontal: 12, paddingVertical: 10, justifyContent: 'space-between', gap: 10 },
  metricHeader: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  metricIcon: { width: 26, height: 26, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  metricLabel: { flex: 1, fontSize: 10, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.4 },
  metricValue: { fontSize: 18, fontWeight: '800' },
  actionRow: { flexDirection: 'row', gap: 10 },
  actionButton: { flex: 1, minHeight: 46, gap: 8, borderRadius: 6 },
  actionPrimary: { backgroundColor: '#16794B', borderWidth: 1, borderColor: '#16794B' },
  actionSecondary: { backgroundColor: '#F4FAF6', borderWidth: 1, borderColor: '#16794B' },
  actionLabel: { fontSize: 13, fontWeight: '700', letterSpacing: 0.2 },
  actionPrimaryLabel: { color: '#FFFFFF' },
  actionSecondaryLabel: { color: '#16794B' },
  categorySection: { gap: 0 },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  sectionTitle: { fontSize: 15, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.4 },
  seeAllButton: { minHeight: 30, paddingHorizontal: 10, paddingVertical: 0, flexDirection: 'row', alignItems: 'center', gap: 2, borderRadius: 999, borderWidth: 1, borderColor: '#CDE8D6', backgroundColor: '#F4FAF6' },
  seeAllText: { fontSize: 11, fontWeight: '700', color: '#16794B', letterSpacing: 0.2 },
  tableHeader: { minHeight: 32, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 8, backgroundColor: '#F1F5F9', borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#D9DEE5' },
  headerCell: { fontSize: 9, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 0.5 },
  categoryColumn: { flex: 1.2 },
  barColumn: { flex: 1.1 },
  qtyColumn: { width: 55, textAlign: 'right' },
  percentColumn: { width: 42, textAlign: 'right' },
  tableRow: { minHeight: 52, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 8, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#CBD5E1' },
  categoryText: { fontSize: 12, fontWeight: '600' },
  qtyText: { fontSize: 12, fontWeight: '700', fontVariant: ['tabular-nums'] },
  percentText: { fontSize: 11, textAlign: 'right' },
  progressTrack: { height: 7, backgroundColor: '#E7EBEF', borderRadius: 99, overflow: 'hidden' },
  progressFill: { height: '100%', minWidth: 2, backgroundColor: '#2D8A61', borderRadius: 99 },
  emptyState: { paddingVertical: 26, alignItems: 'center' },
  centeredState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  stateText: { marginTop: 8 },
});
