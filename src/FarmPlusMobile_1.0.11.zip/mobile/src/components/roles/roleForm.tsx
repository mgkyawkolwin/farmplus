'use client';

import * as React from 'react';
import { useTranslation } from 'react-i18next';
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { ThemedStatusBar as StatusBar } from "@/components/themed-status-bar";
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft } from 'lucide-react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useColorScheme } from 'nativewind';

import { Button } from '@/components/ui/button';
import { Icon } from '@/components/ui/icon';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Text } from '@/components/ui/text';
import SnackBar from '@/components/ui/snack-bar';
import LoadingOverlay from '@/components/loadingOverlay';
import UnauthorizedView from '@/components/unauthorized-view';
import { container, DI_TOKENS } from '@/di';
import { usePagePermission } from '@/lib/usePagePermission';
import { IRoleService } from '@/services/roleService';
import { THEME } from '@/lib/theme';

const roleService = container.resolve<IRoleService>(DI_TOKENS.IRoleService);

export default function RoleFormScreen({ mode }: { mode: 'create' | 'edit' }) {
  const router = useRouter();
  const { t } = useTranslation();
  const params = useLocalSearchParams<{ id?: string | string[] }>();
  const { colorScheme } = useColorScheme() ?? { colorScheme: 'light' };
  const theme = colorScheme === 'dark' ? THEME.dark : THEME.light;
  const roleId = Array.isArray(params.id) ? params.id[0] : params.id;
  const permissionState = usePagePermission(mode === 'create' ? '/roles/new' : '/roles/edit');
  const [role, setRole] = React.useState('');
  const [rowVersion, setRowVersion] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [pageLoading, setPageLoading] = React.useState(mode === 'edit');
  React.useEffect(() => {
    if (mode !== 'edit' || permissionState !== 'authorized') return;
    if (!roleId) {
      router.back();
      return;
    }

    let active = true;
    roleService.getRoleById(roleId).then((item) => {
      if (!active) return;
      setRole(item.role);
      setRowVersion(item.rowVersion ?? '');
    }).catch(() => {
      if (active) {
        SnackBar.Error(t('roles.messages.failedLoadDetails'));
        router.back();
      }
    }).finally(() => {
      if (active) setPageLoading(false);
    });

    return () => { active = false; };
  }, [mode, permissionState, roleId, router]);

  const handleSubmit = async () => {
    const normalizedRole = role.trim();
    if (!normalizedRole) {
      SnackBar.Error(t('roles.messages.roleRequired'));
      return;
    }

    setLoading(true);
    try {
      if (mode === 'create') {
        await roleService.createRole({ role: normalizedRole });
        SnackBar.Success(t('roles.messages.created'));
      } else {
        if (!roleId) return;
        await roleService.updateRole(roleId, { role: normalizedRole, rowVersion });
        SnackBar.Success(t('roles.messages.updated'));
      }
      router.back();
    } catch (error) {
      SnackBar.Error(error instanceof Error ? error.message : t(mode === 'create' ? 'roles.messages.createFailed' : 'roles.messages.updateFailed'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-background" style={styles.page}>
      <StatusBar />
      <LoadingOverlay isLoading={loading} />
      <View className="bg-background border-b border-border" style={styles.headerBar}>
        <Button variant="ghost" onPress={() => router.back()} style={styles.backButton}>
          <Icon className="text-foreground" as={ChevronLeft} size={22} />
        </Button>
        <Text className="text-foreground" style={styles.headerTitle}>{t(mode === 'create' ? 'roles.newTitle' : 'roles.editTitle')}</Text>
        <View style={styles.headerSpacer} />
      </View>

      {permissionState === 'checking' ? (
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color={theme.primary} />
          <Text className="text-muted-foreground" style={styles.loadingText}>{t('roles.checkingPermission')}</Text>
        </View>
      ) : permissionState === 'denied' ? (
        <UnauthorizedView />
      ) : pageLoading ? (
        <View style={styles.centeredState}>
          <ActivityIndicator size="large" color={theme.primary} />
          <Text className="text-muted-foreground" style={styles.loadingText}>{t('roles.loadingDetails')}</Text>
        </View>
      ) : (
        <KeyboardAwareScrollView
          contentContainerStyle={styles.formContent}
          enableOnAndroid
          extraScrollHeight={40}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.field}>
            <Label className="text-foreground">{t('roles.fieldLabel')} <Text style={{ color: theme.destructive }}>*</Text></Label>
            <Input
              placeholder={t('roles.formPlaceholder')}
              value={role}
              onChangeText={setRole}
              maxLength={50}
              editable={!loading}
              className="mt-2"
            />
          </View>
          <View style={styles.actions}>
            <Button variant="outline" style={styles.actionButton} onPress={() => router.back()} disabled={loading}>
              <Text className="text-foreground">{t('roles.actions.cancel')}</Text>
            </Button>
            <Button style={styles.actionButton} onPress={handleSubmit} disabled={loading}>
              {loading ? <ActivityIndicator color={theme.primaryForeground} size="small" /> : (
                <Text className="font-semibold" style={{ color: theme.primaryForeground }}>{t(mode === 'create' ? 'roles.actions.create' : 'roles.actions.saveChanges')}</Text>
              )}
            </Button>
          </View>
        </KeyboardAwareScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  headerBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
    paddingVertical: 4,
  },
  backButton: { minWidth: 40 },
  headerTitle: { textAlign: 'center', fontSize: 18, fontWeight: '600' },
  headerSpacer: { width: 40 },
  formContent: { flexGrow: 1, padding: 20, paddingBottom: 40 },
  field: { marginBottom: 20 },
  actions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 8, marginTop: 8 },
  actionButton: { flex: 1 },
  centeredState: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { marginTop: 8 },
});